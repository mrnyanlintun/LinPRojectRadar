from pathlib import Path
import json, pandas as pd, numpy as np
ROOT=Path(__file__).resolve().parents[1]
report=json.loads((ROOT/"validation_report.json").read_text())
if not report.get("passed"):
    raise SystemExit("Stored validation report is not passing")
for p in ROOT.rglob("*.csv"):
    if p.name=="MANIFEST.csv": continue
    pd.read_csv(p)
print(f"PASS: {report['check_count']} stored checks and all CSV files load")
