from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import shutil
import zipfile
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence, Tuple

import networkx as nx
import numpy as np
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from scipy.optimize import linprog
from scipy.stats import norm, triang

SEED = 20260811
RNG = np.random.default_rng(SEED)
PROGRAMME_VERSION = "OG-SYNTH-0.1"
GENERATOR_VERSION = "generate_opus_synthetic_programme.py@0.1"
DATA_ORIGIN = "SYNTHETIC_RESEARCH_FIXTURE"
ROOT = Path("/mnt/data/Opus_Gubernatio_Synthetic_Programme_v0.1")
PKG_A = ROOT / "package_A_project_structures"
PKG_B = ROOT / "package_B_reference_training_decisions"
PKG_B1 = PKG_B / "B1_reference_population"
PKG_B2 = PKG_B / "B2_expert_epistemic"
PKG_B3 = PKG_B / "B3_decision_optimization"
PKG_C = ROOT / "package_C_optional_activation_lab"
SCHEMAS = ROOT / "schemas"
GENERATORS = ROOT / "generators"
VALIDATORS = ROOT / "validators"

PROJECT_TEMPLATES = [
    ("PRJ-AIR", "Airport Terminal Expansion", "AIRPORT_TERMINAL", 1.20, 385_000_000, "CMAR", "US-NORTHEAST"),
    ("PRJ-HWY", "Highway Corridor Rehabilitation", "HIGHWAY_CORRIDOR", 1.05, 210_000_000, "DESIGN_BUILD", "US-MIDATLANTIC"),
    ("PRJ-HSP", "Vertical Hospital Tower", "VERTICAL_HOSPITAL", 1.15, 460_000_000, "CMAR", "US-SOUTHEAST"),
    ("PRJ-WTR", "Water Treatment Upgrade", "WATER_TREATMENT", 0.95, 175_000_000, "DESIGN_BID_BUILD", "US-MIDWEST"),
    ("PRJ-RAL", "Urban Rail Station Package", "RAIL_STATION", 1.10, 290_000_000, "DESIGN_BUILD", "US-NORTHEAST"),
    ("PRJ-DCT", "Data Center and Commissioning Programme", "DATA_CENTER", 0.90, 240_000_000, "EPCM", "US-WEST"),
]

ACTIVITY_NAMES = {
    "AIRPORT_TERMINAL": ["Notice to Proceed", "Design Release", "Long-Lead Procurement", "Enabling Works", "Foundations", "Structural Frame", "Building Envelope", "MEP Rough-In", "Baggage Systems", "Interior Fit-Out", "Integrated Testing", "Operational Readiness"],
    "HIGHWAY_CORRIDOR": ["Notice to Proceed", "Traffic Control Design", "Utility Relocation", "Clearing and Earthwork", "Drainage", "Subgrade", "Structures", "Base Course", "Paving", "ITS and Lighting", "Punch and Safety Review", "Open to Traffic"],
    "VERTICAL_HOSPITAL": ["Notice to Proceed", "Clinical Design Freeze", "Long-Lead Equipment", "Site and Excavation", "Foundations", "Superstructure", "Envelope", "MEP and Medical Gas", "Interior Build-Out", "Equipment Install", "Commissioning", "Occupancy Readiness"],
    "WATER_TREATMENT": ["Notice to Proceed", "Process Design", "Equipment Procurement", "Site Preparation", "Civil Basins", "Process Structures", "Piping", "Electrical and Controls", "Equipment Installation", "Startup Preparation", "Performance Testing", "Beneficial Use"],
    "RAIL_STATION": ["Notice to Proceed", "Design and Interfaces", "Long-Lead Systems", "Site and Access", "Foundations", "Structural Works", "Platforms and Track", "Envelope", "Systems Integration", "Architectural Finish", "Testing", "Revenue Service Readiness"],
    "DATA_CENTER": ["Notice to Proceed", "Design Release", "Electrical Equipment Procurement", "Site and Foundations", "Shell", "Electrical Rooms", "Mechanical Systems", "White Space Fit-Out", "Controls Integration", "Energization", "Integrated Systems Testing", "Client Turnover"],
}

BASE_DURATIONS = np.array([5, 18, 30, 20, 28, 42, 32, 40, 30, 35, 24, 12], dtype=float)
EDGES = [
    (0, 1), (0, 2), (1, 3), (2, 3), (3, 4), (4, 5), (5, 6), (5, 7),
    (6, 9), (7, 8), (8, 9), (9, 10), (10, 11)
]

CATEGORY_NAMES = {
    1: "Quantitative EVM / Cost & Performance Forecasting",
    2: "Schedule Analytics",
    3: "Cost Risk",
    4: "Document & Risk Signals",
    5: "System Dynamics & Complexity",
    6: "Signal Synthesis",
    7: "Evidence Combination / Epistemic Uncertainty",
    8: "Governance & Compliance",
    9: "Data Integrity & Information Quality",
    10: "Decision Optimization",
}

MODULE_MAP = [
    ("2.1", "PERT Network Criticality", 2, "A", ["schedule_activities.csv", "schedule_dependencies.csv", "schedule_status.csv", "schedule_ground_truth.csv"]),
    ("2.2", "Line of Balance", 2, "A", ["lob_work_packages.csv", "lob_ground_truth.csv"]),
    ("2.3", "CCPM Buffer Health", 2, "A", ["ccpm_buffers.csv", "ccpm_ground_truth.csv"]),
    ("2.5", "Float Consumption Rate", 2, "A", ["schedule_status.csv", "schedule_ground_truth.csv"]),
    ("2.10", "Schedule Risk Analysis P80", 2, "A", ["schedule_activities.csv", "schedule_dependencies.csv", "schedule_status.csv", "schedule_ground_truth.csv"]),
    ("2.11", "Critical Path Index", 2, "A", ["schedule_status.csv", "schedule_ground_truth.csv"]),
    ("3.1", "Reference Class Forecasting", 3, "B1", ["reference_projects.csv", "reference_class_membership.csv", "reference_outcomes.csv"]),
    ("3.6", "Cost Risk Analysis P80", 3, "A", ["cost_elements.csv", "cost_risk_events.csv", "cost_correlations.csv", "cost_risk_ground_truth.csv"]),
    ("3.8", "Parametric Cost Index", 3, "B1/C", ["parametric_cost_training.csv", "ground_truth_model.json", "parametric_cost_benchmark.csv"]),
    ("3.9", "Inflation Adjustment Index", 3, "B1", ["inflation_index.csv"]),
    ("4.5", "Weather Day Impact", 4, "A", ["weather_events.csv", "activity_weather_impacts.csv"]),
    ("4.7", "Dispute Escalation Index", 4, "A", ["claims.csv", "dispute_events.csv", "dispute_ground_truth.csv"]),
    ("4.10", "Specification Conflict Density", 4, "A", ["specification_conflicts.csv", "specification_exposure.csv", "specification_ground_truth.csv"]),
    ("5.1", "DSM Rework Propagation", 5, "A", ["dsm_nodes.csv", "dsm_edges.csv", "dsm_ground_truth.csv"]),
    ("5.5", "Rework Feedback Loop", 5, "A", ["system_dynamics_parameters.csv", "system_dynamics_timeseries.csv"]),
    ("5.6", "Queueing Theory Bottleneck", 5, "A", ["queue_events.csv", "queue_ground_truth.csv"]),
    ("5.7", "Agent-Based Supply Chain", 5, "A", ["agents.csv", "agent_state_history.csv", "abm_ground_truth.csv"]),
    ("5.8", "Discrete Event Simulation", 5, "A", ["des_entities.csv", "des_events.csv", "des_ground_truth.csv"]),
    ("7.2", "Rough Sets", 7, "B1", ["rough_set_decision_table.csv"]),
    ("7.5", "Z-numbers", 7, "B2", ["z_number_assessments.csv"]),
    ("7.6", "PLTS", 7, "B2", ["plts_assessments.csv"]),
    ("7.7", "Plithogenic Sets", 7, "C", ["plithogenic_attributes.csv", "plithogenic_appurtenance.csv", "plithogenic_contradictions.csv"]),
    ("7.8", "Belief Rule Base", 7, "B2", ["belief_rules.json"]),
    ("7.9", "Quantum Probability", 7, "C", ["quantum_order_effects.csv", "quantum_model_parameters.json"]),
    ("7.12", "Hesitant Fuzzy Sets", 7, "B2", ["fuzzy_memberships.csv"]),
    ("7.13", "Type-2 Fuzzy Sets", 7, "B2", ["fuzzy_memberships.csv"]),
    ("7.14", "Maximum Entropy", 7, "B2", ["possibility_distributions.csv", "epistemic_ground_truth.json"]),
    ("7.18", "MARCOS Ranking", 7, "B3", ["alternative_criteria_matrix.csv", "ground_truth_decisions.csv"]),
    ("7.19", "CRITIC-TOPSIS", 7, "B3", ["alternative_criteria_matrix.csv", "ground_truth_decisions.csv"]),
    ("7.20", "Hypersoft Sets", 7, "C", ["hypersoft_universe.csv", "hypersoft_parameters.csv", "hypersoft_approximation.csv"]),
    ("10.1", "Multi-Objective Optimization", 10, "B3/C", ["actions.csv", "criteria.csv", "action_scenario_outcomes.csv", "ground_truth_decisions.csv"]),
    ("10.2", "Linear Programming", 10, "B3/C", ["lp_models.json", "ground_truth_decisions.csv"]),
    ("10.3", "Constraint Satisfaction Analysis", 10, "B3", ["constraints.csv", "ground_truth_decisions.csv"]),
    ("10.4", "What-If Scenario Matrix", 10, "B3", ["actions.csv", "scenarios.csv", "action_scenario_outcomes.csv"]),
    ("10.5", "Decision Sensitivity Matrix", 10, "B3/C", ["sensitivity_cases.csv", "ground_truth_decisions.csv"]),
    ("10.6", "Pareto Frontier Analysis", 10, "B3/C", ["alternative_criteria_matrix.csv", "ground_truth_decisions.csv"]),
    ("10.7", "Regret Minimization Index", 10, "B3", ["payoff_matrices.csv", "ground_truth_decisions.csv"]),
]


def prepare_dirs() -> None:
    if ROOT.exists():
        shutil.rmtree(ROOT)
    for p in [ROOT, PKG_A, PKG_B1, PKG_B2, PKG_B3, PKG_C, SCHEMAS, GENERATORS, VALIDATORS]:
        p.mkdir(parents=True, exist_ok=True)


def json_default(value: Any):
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, (pd.Timestamp, datetime, date)):
        return value.isoformat()
    raise TypeError(f"Cannot serialize {type(value)}")


def row_hash(row: pd.Series) -> str:
    payload = {k: (None if pd.isna(v) else v) for k, v in row.items() if k != "record_hash"}
    raw = json.dumps(payload, sort_keys=True, default=json_default, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def add_provenance(df: pd.DataFrame, package_version: str) -> pd.DataFrame:
    out = df.copy()
    out["data_origin"] = DATA_ORIGIN
    out["programme_version"] = PROGRAMME_VERSION
    out["package_version"] = package_version
    out["generator_version"] = GENERATOR_VERSION
    out["random_seed"] = SEED
    out["not_for_empirical_validation"] = True
    out["record_hash"] = out.apply(row_hash, axis=1)
    return out


def write_csv(df: pd.DataFrame, path: Path, package_version: str) -> None:
    out = add_provenance(df, package_version)
    path.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(path, index=False)


def write_json(obj: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, default=json_default), encoding="utf-8")


def topo_cpm(activity_ids: Sequence[str], durations: Dict[str, float], edges: Sequence[Tuple[str, str]]) -> Dict[str, Any]:
    g = nx.DiGraph()
    g.add_nodes_from(activity_ids)
    g.add_edges_from(edges)
    if not nx.is_directed_acyclic_graph(g):
        raise ValueError("Activity graph must be a DAG")
    topo = list(nx.topological_sort(g))
    es: Dict[str, float] = {}
    ef: Dict[str, float] = {}
    for n in topo:
        preds = list(g.predecessors(n))
        es[n] = max((ef[p] for p in preds), default=0.0)
        ef[n] = es[n] + float(durations[n])
    finish = max(ef.values(), default=0.0)
    lf: Dict[str, float] = {}
    ls: Dict[str, float] = {}
    for n in reversed(topo):
        succ = list(g.successors(n))
        lf[n] = min((ls[s] for s in succ), default=finish)
        ls[n] = lf[n] - float(durations[n])
    tf = {n: ls[n] - es[n] for n in topo}
    critical = [n for n in topo if abs(tf[n]) < 1e-8]
    return {"es": es, "ef": ef, "ls": ls, "lf": lf, "tf": tf, "finish": finish, "critical": critical, "topo": topo, "graph": g}


def beta_pert_sample(low: float, mode: float, high: float, rng: np.random.Generator, size: int, lamb: float = 4.0) -> np.ndarray:
    low, mode, high = float(low), float(mode), float(high)
    if high <= low + 1e-12:
        return np.full(size, low)
    mode = min(max(mode, low), high)
    alpha = 1.0 + lamb * (mode - low) / (high - low)
    beta = 1.0 + lamb * (high - mode) / (high - low)
    return low + rng.beta(alpha, beta, size=size) * (high - low)


def simulate_finish_samples(activity_ids: Sequence[str], edges: Sequence[Tuple[str, str]], samples_by_activity: Dict[str, np.ndarray]) -> np.ndarray:
    g = nx.DiGraph()
    g.add_nodes_from(activity_ids)
    g.add_edges_from(edges)
    topo = list(nx.topological_sort(g))
    n = len(next(iter(samples_by_activity.values())))
    finishes = {a: np.zeros(n) for a in activity_ids}
    for a in topo:
        preds = list(g.predecessors(a))
        start = np.maximum.reduce([finishes[p] for p in preds]) if preds else np.zeros(n)
        finishes[a] = start + samples_by_activity[a]
    return np.maximum.reduce(list(finishes.values()))


def project_dates(start: date, baseline_finish_days: int, buffer_ratio: float = 0.10) -> Tuple[str, str]:
    return start.isoformat(), (start + timedelta(days=int(round(baseline_finish_days * (1 + buffer_ratio))))).isoformat()


def generate_package_a() -> Dict[str, pd.DataFrame]:
    projects_rows: List[Dict[str, Any]] = []
    period_rows: List[Dict[str, Any]] = []
    act_rows: List[Dict[str, Any]] = []
    dep_rows: List[Dict[str, Any]] = []
    status_rows: List[Dict[str, Any]] = []
    sched_gt_rows: List[Dict[str, Any]] = []
    lob_rows: List[Dict[str, Any]] = []
    lob_gt_rows: List[Dict[str, Any]] = []
    ccpm_rows: List[Dict[str, Any]] = []
    ccpm_gt_rows: List[Dict[str, Any]] = []
    dsm_nodes: List[Dict[str, Any]] = []
    dsm_edges: List[Dict[str, Any]] = []
    dsm_gt: List[Dict[str, Any]] = []
    sd_params: List[Dict[str, Any]] = []
    sd_ts: List[Dict[str, Any]] = []
    queue_events: List[Dict[str, Any]] = []
    queue_gt: List[Dict[str, Any]] = []
    agents: List[Dict[str, Any]] = []
    agent_hist: List[Dict[str, Any]] = []
    abm_gt: List[Dict[str, Any]] = []
    des_entities: List[Dict[str, Any]] = []
    des_events: List[Dict[str, Any]] = []
    des_gt: List[Dict[str, Any]] = []
    weather_events: List[Dict[str, Any]] = []
    weather_impacts: List[Dict[str, Any]] = []
    claims: List[Dict[str, Any]] = []
    dispute_events: List[Dict[str, Any]] = []
    dispute_gt: List[Dict[str, Any]] = []
    spec_conflicts: List[Dict[str, Any]] = []
    spec_exposure: List[Dict[str, Any]] = []
    spec_gt: List[Dict[str, Any]] = []
    cost_elements: List[Dict[str, Any]] = []
    cost_risks: List[Dict[str, Any]] = []
    cost_corrs: List[Dict[str, Any]] = []
    cost_gt: List[Dict[str, Any]] = []

    base_start = date(2026, 1, 1)
    drift_factors = {"PRJ-AIR": 0.10, "PRJ-HWY": 0.04, "PRJ-HSP": 0.13, "PRJ-WTR": -0.02, "PRJ-RAL": 0.08, "PRJ-DCT": 0.01}

    for pidx, (pid, pname, archetype, dur_mult, budget, delivery, region) in enumerate(PROJECT_TEMPLATES):
        activity_ids = [f"{pid}-A{i+1:02d}" for i in range(12)]
        durations_arr = np.maximum(3.0, np.round(BASE_DURATIONS * dur_mult + RNG.normal(0, 2.0, 12), 1))
        durations = {aid: float(durations_arr[i]) for i, aid in enumerate(activity_ids)}
        edges = [(activity_ids[a], activity_ids[b]) for a, b in EDGES]
        cpm_base = topo_cpm(activity_ids, durations, edges)
        baseline_finish = int(math.ceil(cpm_base["finish"]))
        start_dt = base_start + timedelta(days=pidx * 21)
        required_finish_day = int(round(baseline_finish * 1.10))
        start_iso, required_finish_iso = project_dates(start_dt, baseline_finish, 0.10)
        projects_rows.append({
            "project_id": pid, "project_name": pname, "archetype": archetype,
            "start_date": start_iso, "baseline_finish_day": baseline_finish,
            "required_finish_day": required_finish_day, "required_finish_date": required_finish_iso,
            "baseline_budget_usd": budget, "delivery_method": delivery, "region": region,
            "study_project_candidate": True,
        })
        for i, aid in enumerate(activity_ids):
            base = durations[aid]
            o = max(1.0, base * (0.78 + RNG.normal(0, 0.02)))
            m = base
            pess = base * (1.28 + RNG.normal(0, 0.03))
            act_rows.append({
                "project_id": pid, "activity_id": aid, "activity_name": ACTIVITY_NAMES[archetype][i],
                "wbs_id": f"{pid}-WBS-{i+1:02d}", "activity_type": "MILESTONE" if i in (0, 11) else "TASK",
                "baseline_duration_days": round(base, 3), "optimistic_duration_days": round(o, 3),
                "most_likely_duration_days": round(m, 3), "pessimistic_duration_days": round(pess, 3),
                "calendar_id": "CAL-5D", "resource_group": ["DESIGN", "PROCUREMENT", "CIVIL", "STRUCTURAL", "MEP", "COMMISSIONING"][min(5, i // 2)],
                "location_id": f"LOC-{(i % 6)+1:02d}", "critical_chain_flag": aid in cpm_base["critical"],
            })
        for a, b in edges:
            dep_rows.append({"project_id": pid, "predecessor_activity_id": a, "successor_activity_id": b, "relationship_type": "FS", "lag_days": 0})

        drift = drift_factors[pid]
        act_lookup = {r["activity_id"]: r for r in act_rows if r["project_id"] == pid}
        for period in range(1, 7):
            period_id = f"P{period:02d}"
            period_start = start_dt + timedelta(days=int((period - 1) * required_finish_day / 6))
            period_end = start_dt + timedelta(days=int(period * required_finish_day / 6) - 1)
            status_day = int(round(required_finish_day * period / 7.0))
            period_rows.append({
                "project_id": pid, "period_id": period_id, "period_number": period,
                "period_start": period_start.isoformat(), "period_end": period_end.isoformat(),
                "status_date": (start_dt + timedelta(days=status_day)).isoformat(),
                "status_day": status_day,
            })
            progress_map: Dict[str, float] = {}
            current_durations: Dict[str, float] = {}
            for i, aid in enumerate(activity_ids):
                es, ef = cpm_base["es"][aid], cpm_base["ef"][aid]
                if status_day >= ef:
                    base_prog = 1.0
                elif status_day <= es:
                    base_prog = 0.0
                else:
                    base_prog = (status_day - es) / max(durations[aid], 1e-9)
                activity_risk = ((i % 4) - 1.5) * 0.015
                prog = float(np.clip(base_prog * (1 - drift * period / 7.0) + RNG.normal(0, 0.025), 0, 1))
                progress_map[aid] = prog
                rem = max(0.0, durations[aid] * (1 - prog) * (1 + drift + activity_risk))
                current_durations[aid] = rem
            cpm_cur = topo_cpm(activity_ids, current_durations, edges)
            current_finish = status_day + cpm_cur["finish"]
            # stochastic remaining durations
            samples_by_act: Dict[str, np.ndarray] = {}
            nmc = 2500
            for aid in activity_ids:
                prog = progress_map[aid]
                row = act_lookup[aid]
                mult = (1 + drift)
                low = row["optimistic_duration_days"] * (1 - prog) * mult
                mode = row["most_likely_duration_days"] * (1 - prog) * mult
                high = row["pessimistic_duration_days"] * (1 - prog) * mult
                samples_by_act[aid] = beta_pert_sample(low, mode, high, RNG, nmc)
            finish_samples = status_day + simulate_finish_samples(activity_ids, edges, samples_by_act)
            p50 = float(np.quantile(finish_samples, 0.50))
            p80 = float(np.quantile(finish_samples, 0.80))
            ontime = float(np.mean(finish_samples <= required_finish_day))
            baseline_remaining_sum = sum(durations[a] * max(0.0, 1 - progress_map[a]) for a in activity_ids)
            current_remaining_sum = sum(current_durations.values())
            sci = baseline_remaining_sum / current_remaining_sum if current_remaining_sum > 0 else 1.0
            for aid in activity_ids:
                prog = progress_map[aid]
                actual_start = cpm_base["es"][aid] if prog > 0 else np.nan
                actual_finish = cpm_base["ef"][aid] if prog >= 1 else np.nan
                status_rows.append({
                    "project_id": pid, "period_id": period_id, "activity_id": aid,
                    "progress_fraction": round(prog, 6),
                    "actual_start_day": actual_start, "actual_finish_day": actual_finish,
                    "current_remaining_duration_days": round(current_durations[aid], 6),
                    "forecast_start_day": round(status_day + cpm_cur["es"][aid], 6),
                    "forecast_finish_day": round(status_day + cpm_cur["ef"][aid], 6),
                    "current_total_float_days": round(cpm_cur["tf"][aid], 6),
                    "current_critical_flag": aid in cpm_cur["critical"],
                    "schedule_version": f"{pid}-{period_id}-V1",
                })
            sched_gt_rows.append({
                "project_id": pid, "period_id": period_id, "status_day": status_day,
                "baseline_finish_day": baseline_finish, "current_forecast_finish_day": round(current_finish, 6),
                "required_finish_day": required_finish_day, "schedule_margin_days": round(required_finish_day - current_finish, 6),
                "p50_finish_day": round(p50, 6), "p80_finish_day": round(p80, 6),
                "p80_overrun_days": round(max(0.0, p80 - required_finish_day), 6),
                "probability_finish_by_required_date": round(ontime, 6),
                "critical_path_activity_ids": "|".join(cpm_cur["critical"]),
                "schedule_compression_index": round(sci, 6),
                "monte_carlo_iterations": nmc,
            })

        # LOB for repetitive archetypes
        if archetype in {"HIGHWAY_CORRIDOR", "VERTICAL_HOSPITAL", "RAIL_STATION"}:
            work_types = ["EARLY_WORK", "STRUCTURE", "SYSTEMS", "FINISH"]
            planned_rates = [0.22, 0.18, 0.16, 0.20]  # locations/day
            for period in range(1, 7):
                period_id = f"P{period:02d}"
                actual_rates = [r * (1 + RNG.normal(0, 0.06) - drift * 0.4) for r in planned_rates]
                starts = [0, 18, 38, 62]
                for wt_idx, wt in enumerate(work_types):
                    for loc in range(1, 7):
                        planned_start = starts[wt_idx] + (loc - 1) / planned_rates[wt_idx]
                        actual_start = starts[wt_idx] + (loc - 1) / max(actual_rates[wt_idx], 0.05) + period * drift * 2
                        lob_rows.append({
                            "project_id": pid, "period_id": period_id, "location_id": f"L{loc:02d}",
                            "location_sequence": loc, "work_type_id": wt, "crew_id": f"{pid}-{wt}-CREW",
                            "quantity": 1, "unit": "location", "planned_production_rate_locations_per_day": planned_rates[wt_idx],
                            "actual_production_rate_locations_per_day": round(actual_rates[wt_idx], 6),
                            "planned_start_day": round(planned_start, 6), "actual_start_day": round(actual_start, 6),
                            "minimum_separation_days": 5,
                        })
                for i in range(len(work_types)-1):
                    r1, r2 = actual_rates[i], actual_rates[i+1]
                    s1, s2 = starts[i] + period * drift * 2, starts[i+1] + period * drift * 2
                    denom = (1/r1 - 1/r2) if r1 > 0 and r2 > 0 else 0
                    catch_loc = (s2 - s1) / denom if abs(denom) > 1e-12 else np.nan
                    within = bool(not np.isnan(catch_loc) and 1 <= catch_loc <= 6)
                    lob_gt_rows.append({
                        "project_id": pid, "period_id": period_id,
                        "leading_work_type": work_types[i], "following_work_type": work_types[i+1],
                        "leading_rate": round(r1, 6), "following_rate": round(r2, 6),
                        "catch_up_location": round(catch_loc, 6) if not np.isnan(catch_loc) else np.nan,
                        "interference_within_project": within,
                    })

        # CCPM data and GT
        original_buffer = max(10.0, baseline_finish * 0.15)
        for period in range(1, 7):
            period_id = f"P{period:02d}"
            sched_gt = next(r for r in sched_gt_rows if r["project_id"] == pid and r["period_id"] == period_id)
            chain_progress = min(0.98, period / 6.0)
            delay_component = max(0.0, sched_gt["current_forecast_finish_day"] - baseline_finish)
            consumed = min(original_buffer, original_buffer * chain_progress * 0.60 + delay_component * 0.35)
            remaining = max(0.0, original_buffer - consumed)
            ccpm_rows.append({
                "project_id": pid, "period_id": period_id, "buffer_id": f"{pid}-PB",
                "buffer_type": "PROJECT", "chain_id": f"{pid}-CC", "original_buffer_days": round(original_buffer, 6),
                "remaining_buffer_days": round(remaining, 6), "chain_progress_fraction": round(chain_progress, 6),
                "buffer_sizing_method": "SYNTHETIC_15_PERCENT_BASELINE",
            })
            for fb in range(1, 3):
                fb_orig = original_buffer * (0.25 + 0.05*fb)
                fb_consumed = min(fb_orig, consumed * (0.15 + 0.05*fb))
                ccpm_rows.append({
                    "project_id": pid, "period_id": period_id, "buffer_id": f"{pid}-FB{fb}",
                    "buffer_type": "FEEDING", "chain_id": f"{pid}-FC{fb}", "original_buffer_days": round(fb_orig, 6),
                    "remaining_buffer_days": round(fb_orig-fb_consumed, 6), "chain_progress_fraction": round(chain_progress, 6),
                    "buffer_sizing_method": "SYNTHETIC_FEEDING_BUFFER",
                })
            ccpm_gt_rows.append({
                "project_id": pid, "period_id": period_id,
                "project_buffer_consumed_days": round(consumed, 6),
                "project_buffer_consumption_ratio": round(consumed/original_buffer, 6),
                "buffer_to_progress_ratio": round((consumed/original_buffer)/max(chain_progress, 1e-9), 6),
                "buffer_exhausted": remaining <= 1e-9,
            })

        # DSM
        node_names = ["DESIGN", "PROCUREMENT", "CIVIL", "STRUCTURE", "MEP", "CONTROLS", "TESTING", "TURNOVER"]
        node_ids = [f"{pid}-DSM-{i+1:02d}" for i in range(len(node_names))]
        for nid, nname in zip(node_ids, node_names):
            dsm_nodes.append({"project_id": pid, "node_id": nid, "node_name": nname, "node_type": "WORKSTREAM"})
        matrix = np.zeros((8, 8))
        dsm_pairs = [(0,1,0.25),(0,2,0.20),(1,4,0.30),(2,3,0.25),(3,4,0.25),(4,5,0.35),(5,6,0.40),(6,7,0.30),(4,2,0.10)]
        for s,t,w in dsm_pairs:
            w2 = min(0.75, max(0.02, w + RNG.normal(0,0.025)))
            matrix[t,s] = w2
            dsm_edges.append({"project_id": pid, "source_node_id": node_ids[s], "target_node_id": node_ids[t], "dependency_type": "REWORK_PROPAGATION", "dependency_strength": round(w2, 6), "propagation_delay_periods": 1})
        for period in range(1,7):
            seed = np.zeros(8)
            seed[(period-1) % 4] = 1.0 + 0.15*period
            cur = seed.copy()
            cumulative = seed.copy()
            for _ in range(3):
                cur = matrix @ cur
                cumulative += cur
            dsm_gt.append({
                "project_id": pid, "period_id": f"P{period:02d}", "seed_node_id": node_ids[(period-1)%4],
                "propagation_steps": 3, "total_propagated_rework": round(float(cumulative.sum()-seed.sum()), 6),
                "impacted_node_count": int(np.sum(cumulative > 0.05)),
                "cumulative_impact_vector": json.dumps({node_ids[i]: round(float(cumulative[i]), 6) for i in range(8)}, sort_keys=True),
            })

        # System dynamics
        error_rate = 0.035 + max(0, drift)*0.06
        productivity = 22.0 * (1 - max(0, drift)*0.3)
        feedback_gain = 0.015 + max(0, drift)*0.04
        sd_params.extend([
            {"project_id": pid, "parameter_name": "error_rate", "parameter_value": error_rate, "unit": "fraction"},
            {"project_id": pid, "parameter_name": "base_productivity", "parameter_value": productivity, "unit": "work_units_per_step"},
            {"project_id": pid, "parameter_name": "feedback_gain", "parameter_value": feedback_gain, "unit": "fraction_per_backlog_unit"},
        ])
        backlog = 55.0 + pidx*4
        cumulative_rework = 0.0
        for t in range(1,13):
            new_work = max(5.0, 18.0 - 0.8*t + RNG.normal(0,1.2))
            completed = min(backlog + new_work, productivity * (1 - 0.02*t/12))
            rework = max(0.0, error_rate*completed + feedback_gain*backlog + RNG.normal(0,0.4))
            next_backlog = max(0.0, backlog + new_work + rework - completed)
            cumulative_rework += rework
            sd_ts.append({
                "project_id": pid, "time_step": t, "backlog_start": round(backlog, 6), "new_work": round(new_work, 6),
                "work_completed": round(completed, 6), "rework_generated": round(rework, 6), "backlog_end": round(next_backlog, 6),
                "cumulative_rework": round(cumulative_rework, 6),
            })
            backlog = next_backlog

        # Queueing simulation (RFI review)
        n_entities = 40
        interarrivals = RNG.exponential(scale=2.5 + pidx*0.15, size=n_entities)
        arrivals = np.cumsum(interarrivals)
        services = RNG.lognormal(mean=math.log(2.4 + pidx*0.1), sigma=0.35, size=n_entities)
        server_free = [0.0, 0.0]
        waits = []
        busy = [0.0, 0.0]
        for e in range(n_entities):
            sidx = int(np.argmin(server_free))
            start = max(arrivals[e], server_free[sidx])
            end = start + services[e]
            wait = start - arrivals[e]
            server_free[sidx] = end
            busy[sidx] += services[e]
            waits.append(wait)
            queue_events.append({
                "project_id": pid, "queue_id": f"{pid}-RFI-REVIEW", "entity_id": f"{pid}-RFI-{e+1:03d}",
                "arrival_time_day": round(float(arrivals[e]), 6), "service_start_day": round(float(start), 6),
                "service_end_day": round(float(end), 6), "service_duration_days": round(float(services[e]), 6),
                "wait_time_days": round(float(wait), 6), "server_id": f"REVIEWER-{sidx+1}", "queue_discipline": "FCFS",
            })
        horizon = max(server_free)
        queue_gt.append({
            "project_id": pid, "queue_id": f"{pid}-RFI-REVIEW", "entities": n_entities,
            "servers": 2, "mean_wait_days": round(float(np.mean(waits)), 6), "p90_wait_days": round(float(np.quantile(waits,0.9)), 6),
            "throughput_per_day": round(n_entities/horizon, 6), "server_1_utilization": round(busy[0]/horizon, 6),
            "server_2_utilization": round(busy[1]/horizon, 6),
        })

        # ABM supply chain
        n_agents = 8
        agent_ids = []
        for a in range(n_agents):
            aid = f"{pid}-SUP-{a+1:02d}"
            agent_ids.append(aid)
            reliability = 0.82 + 0.02*(a%4) - max(0,drift)*0.15
            capacity = 8 + a%3*2
            lead = 2 + (a%4)
            agents.append({
                "project_id": pid, "agent_id": aid, "agent_type": "SUPPLIER", "base_capacity_units": capacity,
                "base_lead_time_steps": lead, "reliability": round(reliability,6), "decision_rule_id": "RESTOCK_AND_PRIORITIZE_CRITICAL",
                "network_group": f"G{a%3+1}",
            })
        delivered_total = 0.0
        demanded_total = 0.0
        disruption_count = 0
        lead_records = []
        inventories = {aid: 12.0 + i for i, aid in enumerate(agent_ids)}
        for t in range(1,13):
            for i, aid in enumerate(agent_ids):
                base_cap = 8 + i%3*2
                demand = max(2.0, 5.0 + RNG.normal(0,1.0))
                disruption = RNG.random() > (0.82 + 0.02*(i%4) - max(0,drift)*0.15)
                if disruption:
                    disruption_count += 1
                effective_cap = base_cap * (0.45 if disruption else 1.0)
                delivered = min(demand, inventories[aid], effective_cap)
                inventories[aid] = max(0.0, inventories[aid] - delivered + base_cap*0.75)
                lead = 2 + (i%4) + (2 if disruption else 0)
                delivered_total += delivered
                demanded_total += demand
                lead_records.append(lead)
                agent_hist.append({
                    "project_id": pid, "time_step": t, "agent_id": aid, "state": "DISRUPTED" if disruption else "NORMAL",
                    "demand_units": round(demand,6), "delivered_units": round(delivered,6),
                    "inventory_end_units": round(inventories[aid],6), "effective_capacity_units": round(effective_cap,6),
                    "lead_time_steps": lead,
                })
        abm_gt.append({
            "project_id": pid, "agents": n_agents, "time_steps": 12,
            "service_level": round(delivered_total/demanded_total,6), "average_lead_time_steps": round(float(np.mean(lead_records)),6),
            "disruption_events": disruption_count,
        })

        # DES procurement pipeline
        stages = ["REVIEW", "FABRICATION", "SHIPPING", "DELIVERY"]
        capacities = {"REVIEW": 2, "FABRICATION": 3, "SHIPPING": 2, "DELIVERY": 4}
        base_service = {"REVIEW": 3.0, "FABRICATION": 12.0, "SHIPPING": 6.0, "DELIVERY": 1.5}
        stage_free = {s:[0.0]*capacities[s] for s in stages}
        cycle_times=[]
        stage_waits={s:[] for s in stages}
        for item in range(1,21):
            entity=f"{pid}-ITEM-{item:03d}"
            des_entities.append({"project_id":pid,"entity_id":entity,"entity_type":"LONG_LEAD_ITEM","priority":"CRITICAL" if item%5==0 else "NORMAL"})
            current = float(RNG.uniform(0,15))
            first=current
            for s in stages:
                servers=stage_free[s]
                idx=int(np.argmin(servers))
                start=max(current,servers[idx])
                wait=start-current
                duration=max(0.2,float(RNG.lognormal(mean=math.log(base_service[s]),sigma=0.25)))
                end=start+duration
                servers[idx]=end
                stage_waits[s].append(wait)
                des_events.append({
                    "project_id":pid,"entity_id":entity,"event_id":f"{entity}-{s}","event_type":s,
                    "queue_id":f"Q-{s}","resource_id":f"{s}-SERVER-{idx+1}","event_arrival_day":round(current,6),
                    "event_start_day":round(start,6),"event_end_day":round(end,6),"wait_days":round(wait,6),
                    "service_duration_days":round(duration,6),"routing_rule":"SEQUENTIAL_PIPELINE",
                })
                current=end
            cycle_times.append(current-first)
        des_gt.append({
            "project_id":pid,"entities":20,"mean_cycle_time_days":round(float(np.mean(cycle_times)),6),
            "p80_cycle_time_days":round(float(np.quantile(cycle_times,0.8)),6),
            "bottleneck_stage":max(stage_waits,key=lambda s:np.mean(stage_waits[s])),
            "mean_wait_by_stage_json":json.dumps({s:round(float(np.mean(v)),6) for s,v in stage_waits.items()},sort_keys=True),
        })

        # Weather impacts
        critical_ids = set(cpm_base["critical"])
        for w in range(1,13):
            event_day = int(RNG.integers(1, required_finish_day+1))
            aid = activity_ids[int(RNG.integers(3,10))]
            weather_type = ["HEAVY_RAIN","HIGH_WIND","EXTREME_HEAT","SNOW_ICE"][w%4]
            threshold_excess = float(RNG.uniform(0.2,1.6))
            lost = max(0.0, round(threshold_excess * (1.2 + 0.4*(w%3)), 2))
            critical = aid in critical_ids
            impact = lost*(1.0 if critical else 0.30)
            wid=f"{pid}-WX-{w:02d}"
            weather_events.append({
                "project_id":pid,"weather_event_id":wid,"event_day":event_day,"weather_type":weather_type,
                "threshold_exceedance_index":round(threshold_excess,6),"normal_allowance_days":0.5,"lost_work_days":lost,
            })
            weather_impacts.append({
                "project_id":pid,"weather_event_id":wid,"affected_activity_id":aid,"critical_at_event":critical,
                "productivity_loss_fraction":round(min(0.8,0.15*threshold_excess),6),"ground_truth_schedule_impact_days":round(impact,6),
                "excusable_flag":threshold_excess>0.8,
            })

        # Claims/disputes
        stages_claim=["NOTICE","CLAIM_SUBMITTED","NEGOTIATION","MEDIATION","ADJUDICATION"]
        for c in range(1,7):
            cid=f"{pid}-CLM-{c:02d}"
            stage_index=min(4, max(0, c-2 + (1 if drift>0.07 else 0)))
            submitted=int(required_finish_day*(0.15+0.1*c))
            value=float(budget*(0.002+0.0015*c)*(1+max(0,drift)))
            claims.append({
                "project_id":pid,"claim_id":cid,"notice_id":f"{cid}-N","claim_type":["DESIGN_CHANGE","DIFFERING_SITE","DELAY","PAYMENT"][c%4],
                "claim_value_usd":round(value,2),"submitted_day":submitted,"current_stage":stages_claim[stage_index],
                "unresolved_age_days":max(0,required_finish_day-submitted),"adjudication_status":"OPEN" if stage_index<4 else "PENDING_DECISION",
            })
            for sidx in range(stage_index+1):
                dispute_events.append({
                    "project_id":pid,"claim_id":cid,"event_sequence":sidx+1,"stage":stages_claim[sidx],
                    "event_day":submitted+sidx*18,"event_type":"STAGE_ADVANCE",
                })
            severity=(stage_index/4)*0.7+min(0.3,value/(budget*0.05)*0.3)
            dispute_gt.append({
                "project_id":pid,"claim_id":cid,"ground_truth_stage_index":stage_index,"ground_truth_escalation_severity":round(severity,6),
                "direct_dispute_evidence_present":True,
            })

        # Specification conflict density
        exposure=1400+200*pidx
        spec_exposure.append({"project_id":pid,"specification_sections_reviewed":140+10*pidx,"clauses_reviewed":exposure,"exposure_unit":"CLAUSE"})
        confirmed=0
        for sc in range(1,13):
            review=["CONFIRMED","REJECTED","PENDING"][sc%3]
            if review=="CONFIRMED": confirmed+=1
            spec_conflicts.append({
                "project_id":pid,"conflict_id":f"{pid}-SC-{sc:02d}","document_a_id":f"SPEC-{sc%5+1}","document_b_id":f"DRAW-{sc%7+1}",
                "clause_a":f"{sc%8+1}.{sc}","clause_b":f"D-{sc%6+1}-{sc:03d}","discipline":["ARCH","CIVIL","MEP","STRUCT"][sc%4],
                "conflict_type":["DIMENSION","MATERIAL","SEQUENCE","RESPONSIBILITY"][sc%4],"review_status":review,
            })
        spec_gt.append({"project_id":pid,"confirmed_conflicts":confirmed,"clauses_reviewed":exposure,"conflicts_per_1000_clauses":round(confirmed/exposure*1000,6)})

        # Cost risk model
        weights=RNG.dirichlet(np.ones(10)*1.8)
        elem_names=["DESIGN","GENERAL_CONDITIONS","CIVIL","STRUCTURE","ENVELOPE","MEP","SYSTEMS","PROCUREMENT","COMMISSIONING","CONTINGENCY"]
        lows=[]; modes=[]; highs=[]
        for i,name in enumerate(elem_names):
            mode=budget*weights[i]
            spread=0.08+0.02*(i%4)+max(0,drift)*0.15
            low=mode*(1-spread*0.55)
            high=mode*(1+spread)
            lows.append(low); modes.append(mode); highs.append(high)
            cost_elements.append({
                "project_id":pid,"cost_element_id":f"{pid}-CE-{i+1:02d}","cost_element_name":name,
                "low_cost_usd":round(low,2),"most_likely_cost_usd":round(mode,2),"high_cost_usd":round(high,2),
                "correlation_group":f"CG-{i//3+1}",
            })
        corr=np.full((10,10),0.04)
        np.fill_diagonal(corr,1.0)
        for i in range(10):
            for j in range(10):
                if i//3==j//3 and i!=j: corr[i,j]=0.25
                cost_corrs.append({"project_id":pid,"cost_element_id_a":f"{pid}-CE-{i+1:02d}","cost_element_id_b":f"{pid}-CE-{j+1:02d}","correlation":corr[i,j]})
        risk_defs=[]
        for r in range(1,7):
            prob=0.12+0.06*(r%4)+max(0,drift)*0.25
            low_i=budget*(0.001*r)
            mode_i=budget*(0.002*r)
            high_i=budget*(0.004*r)
            rid=f"{pid}-CR-{r:02d}"
            risk_defs.append((prob,low_i,mode_i,high_i))
            cost_risks.append({
                "project_id":pid,"risk_event_id":rid,"risk_name":["DESIGN_GROWTH","MARKET_ESCALATION","PRODUCTIVITY","PROCUREMENT","WEATHER","COMMISSIONING"][r-1],
                "probability":round(prob,6),"low_impact_usd":round(low_i,2),"most_likely_impact_usd":round(mode_i,2),"high_impact_usd":round(high_i,2),
            })
        nmc=5000
        chol=np.linalg.cholesky(corr)
        z=RNG.normal(size=(nmc,10))@chol.T
        u=norm.cdf(z)
        element_samples=np.zeros((nmc,10))
        for i in range(10):
            c=(modes[i]-lows[i])/(highs[i]-lows[i])
            element_samples[:,i]=triang.ppf(u[:,i],c=c,loc=lows[i],scale=highs[i]-lows[i])
        risk_total=np.zeros(nmc)
        for prob,lo,mo,hi in risk_defs:
            occurs=RNG.random(nmc)<prob
            c=(mo-lo)/(hi-lo)
            impacts=triang.rvs(c=c,loc=lo,scale=hi-lo,size=nmc,random_state=RNG)
            risk_total+=occurs*impacts
        total=element_samples.sum(axis=1)+risk_total
        cost_gt.append({
            "project_id":pid,"monte_carlo_iterations":nmc,"p50_total_cost_usd":round(float(np.quantile(total,0.5)),2),
            "p80_total_cost_usd":round(float(np.quantile(total,0.8)),2),"mean_total_cost_usd":round(float(np.mean(total)),2),
            "probability_exceed_baseline_budget":round(float(np.mean(total>budget)),6),
        })

    data = {
        "projects.csv": pd.DataFrame(projects_rows),
        "reporting_periods.csv": pd.DataFrame(period_rows),
        "schedule_activities.csv": pd.DataFrame(act_rows),
        "schedule_dependencies.csv": pd.DataFrame(dep_rows),
        "schedule_status.csv": pd.DataFrame(status_rows),
        "schedule_ground_truth.csv": pd.DataFrame(sched_gt_rows),
        "lob_work_packages.csv": pd.DataFrame(lob_rows),
        "lob_ground_truth.csv": pd.DataFrame(lob_gt_rows),
        "ccpm_buffers.csv": pd.DataFrame(ccpm_rows),
        "ccpm_ground_truth.csv": pd.DataFrame(ccpm_gt_rows),
        "dsm_nodes.csv": pd.DataFrame(dsm_nodes),
        "dsm_edges.csv": pd.DataFrame(dsm_edges),
        "dsm_ground_truth.csv": pd.DataFrame(dsm_gt),
        "system_dynamics_parameters.csv": pd.DataFrame(sd_params),
        "system_dynamics_timeseries.csv": pd.DataFrame(sd_ts),
        "queue_events.csv": pd.DataFrame(queue_events),
        "queue_ground_truth.csv": pd.DataFrame(queue_gt),
        "agents.csv": pd.DataFrame(agents),
        "agent_state_history.csv": pd.DataFrame(agent_hist),
        "abm_ground_truth.csv": pd.DataFrame(abm_gt),
        "des_entities.csv": pd.DataFrame(des_entities),
        "des_events.csv": pd.DataFrame(des_events),
        "des_ground_truth.csv": pd.DataFrame(des_gt),
        "weather_events.csv": pd.DataFrame(weather_events),
        "activity_weather_impacts.csv": pd.DataFrame(weather_impacts),
        "claims.csv": pd.DataFrame(claims),
        "dispute_events.csv": pd.DataFrame(dispute_events),
        "dispute_ground_truth.csv": pd.DataFrame(dispute_gt),
        "specification_conflicts.csv": pd.DataFrame(spec_conflicts),
        "specification_exposure.csv": pd.DataFrame(spec_exposure),
        "specification_ground_truth.csv": pd.DataFrame(spec_gt),
        "cost_elements.csv": pd.DataFrame(cost_elements),
        "cost_risk_events.csv": pd.DataFrame(cost_risks),
        "cost_correlations.csv": pd.DataFrame(cost_corrs),
        "cost_risk_ground_truth.csv": pd.DataFrame(cost_gt),
    }
    for name, df in data.items():
        write_csv(df, PKG_A / name, "A-0.1")
    return data


def size_band(cost: float) -> str:
    if cost < 75_000_000: return "SMALL"
    if cost < 200_000_000: return "MEDIUM"
    if cost < 400_000_000: return "LARGE"
    return "MEGA"


def generate_package_b1() -> Dict[str, pd.DataFrame]:
    rows=[]; periods=[]; memberships=[]; outcomes=[]; anomalies=[]; split_rows=[]; rough_rows=[]; param_rows=[]
    archetypes=[x[2] for x in PROJECT_TEMPLATES]
    delivery_methods=["DESIGN_BID_BUILD","DESIGN_BUILD","CMAR","EPCM"]
    regions=["US-NORTHEAST","US-SOUTHEAST","US-MIDWEST","US-WEST"]
    type_base={"AIRPORT_TERMINAL":85,"HIGHWAY_CORRIDOR":45,"VERTICAL_HOSPITAL":95,"WATER_TREATMENT":55,"RAIL_STATION":70,"DATA_CENTER":60}
    delivery_effect={"DESIGN_BID_BUILD":0.04,"DESIGN_BUILD":-0.01,"CMAR":0.0,"EPCM":0.02}
    region_factor={"US-NORTHEAST":1.18,"US-SOUTHEAST":0.94,"US-MIDWEST":0.91,"US-WEST":1.12}
    injected_ids=set(RNG.choice(np.arange(360),size=28,replace=False).tolist())
    project_ids=[]
    for i in range(360):
        ptype=archetypes[i%6]
        delivery=delivery_methods[(i//6)%4]
        region=regions[(i//24)%4]
        complexity=float(np.clip(RNG.beta(2.2,2.0),0.05,0.98))
        design_completeness=float(np.clip(RNG.beta(4.5,1.8),0.35,0.99))
        gross_area=max(0.0,float(RNG.normal(45000 if ptype in {"AIRPORT_TERMINAL","VERTICAL_HOSPITAL","DATA_CENTER"} else 10000,12000)))
        length_km=max(0.0,float(RNG.normal(18 if ptype in {"HIGHWAY_CORRIDOR","RAIL_STATION"} else 1.5,5)))
        capacity=max(1.0,float(RNG.normal(120 if ptype in {"WATER_TREATMENT","DATA_CENTER"} else 60,25)))
        floors=max(1,int(RNG.normal(10 if ptype=="VERTICAL_HOSPITAL" else 4,3)))
        loc=region_factor[region]
        base_m=type_base[ptype]
        cost_m=(base_m + 0.0009*gross_area + 2.6*length_km + 0.18*capacity + 1.8*floors + 55*complexity)*loc
        cost_m*=1+delivery_effect[delivery]
        cost_m=max(15.0,cost_m+RNG.normal(0,8.0))
        baseline=cost_m*1_000_000
        duration=max(180,int(250+1.2*math.sqrt(gross_area)+3.5*length_km+160*complexity+RNG.normal(0,35)))
        overrun=0.015+0.18*complexity+0.12*(1-design_completeness)+delivery_effect[delivery]+RNG.normal(0,0.055)
        sched_overrun=0.01+0.22*complexity+0.10*(1-design_completeness)+RNG.normal(0,0.07)
        anomaly=i in injected_ids
        if anomaly:
            overrun+=float(RNG.uniform(0.25,0.55)); sched_overrun+=float(RNG.uniform(0.20,0.50))
        overrun=float(np.clip(overrun,-0.08,0.75)); sched_overrun=float(np.clip(sched_overrun,-0.10,0.80))
        final=baseline*(1+overrun); final_duration=duration*(1+sched_overrun)
        outcome_class="GREEN" if overrun<0.08 and sched_overrun<0.08 else ("AMBER" if overrun<0.22 and sched_overrun<0.22 else "RED")
        pid=f"REF-{i+1:04d}"; project_ids.append(pid)
        row={
            "reference_project_id":pid,"project_type":ptype,"delivery_method":delivery,"region":region,
            "gross_area_m2":round(gross_area,3),"length_km":round(length_km,3),"capacity_units":round(capacity,3),"floors":floors,
            "complexity_index":round(complexity,6),"design_completeness":round(design_completeness,6),"location_factor":loc,
            "baseline_cost_usd":round(baseline,2),"final_cost_usd":round(final,2),"baseline_duration_days":duration,"final_duration_days":round(final_duration,3),
            "cost_overrun_pct":round(overrun,6),"schedule_overrun_pct":round(sched_overrun,6),"outcome_class":outcome_class,
            "known_anomaly_label":anomaly,
        }
        rows.append(row); outcomes.append({k:row[k] for k in ["reference_project_id","final_cost_usd","final_duration_days","cost_overrun_pct","schedule_overrun_pct","outcome_class","known_anomaly_label"]})
        rclass=f"{ptype}|{size_band(baseline)}|{delivery}"
        memberships.append({"reference_project_id":pid,"reference_class_id":rclass,"membership_rule":"TYPE_SIZE_DELIVERY","inclusion_flag":True})
        anomalies.append({"reference_project_id":pid,"known_anomaly_label":anomaly,"anomaly_reason":"INJECTED_EXTREME_OVERRUN" if anomaly else "NONE"})
        param_rows.append({k:row[k] for k in ["reference_project_id","project_type","delivery_method","region","gross_area_m2","length_km","capacity_units","floors","complexity_index","design_completeness","location_factor","baseline_cost_usd"]})
        final_cpi=float(np.clip(baseline/final,0.45,1.25)); final_spi=float(np.clip(duration/final_duration,0.45,1.25))
        for per in range(1,9):
            progress=per/8
            cpi=float(np.clip(1+(final_cpi-1)*progress+RNG.normal(0,0.025),0.4,1.35))
            spi=float(np.clip(1+(final_spi-1)*progress+RNG.normal(0,0.025),0.4,1.35))
            doc_risk=float(np.clip(0.15+0.55*max(overrun,sched_overrun)*progress+RNG.normal(0,0.04),0,1))
            rfi_open=max(0,int(RNG.poisson(2+18*complexity*progress)))
            change_orders=max(0,int(RNG.poisson(1+10*overrun*progress)))
            quality_findings=max(0,int(RNG.poisson(1+5*complexity*progress)))
            procurement_at_risk=max(0,int(RNG.poisson(1+8*max(0,sched_overrun)*progress)))
            periods.append({
                "reference_project_id":pid,"period_number":per,"progress_fraction":round(progress,6),"cpi":round(cpi,6),"spi":round(spi,6),
                "document_risk_score":round(doc_risk,6),"rfi_open":rfi_open,"change_order_count":change_orders,
                "quality_findings":quality_findings,"procurement_items_at_risk":procurement_at_risk,
            })
        # Rough table uses early/mid signals
        early_cpi=periods[-6]["cpi"]; early_spi=periods[-6]["spi"]; early_doc=periods[-6]["document_risk_score"]
        rough_rows.append({
            "reference_project_id":pid,"complexity_band":"LOW" if complexity<0.35 else ("MEDIUM" if complexity<0.65 else "HIGH"),
            "early_cpi_band":"LOW" if early_cpi<0.9 else ("MID" if early_cpi<1.05 else "HIGH"),
            "early_spi_band":"LOW" if early_spi<0.9 else ("MID" if early_spi<1.05 else "HIGH"),
            "document_risk_band":"LOW" if early_doc<0.3 else ("MEDIUM" if early_doc<0.6 else "HIGH"),
            "decision_class":outcome_class,
        })
    # project-level split
    perm=RNG.permutation(project_ids)
    n=len(perm); split_map={pid:("DEVELOPMENT" if idx<int(0.6*n) else ("VALIDATION" if idx<int(0.8*n) else "LOCKED_HOLDOUT")) for idx,pid in enumerate(perm)}
    split_rows=[{"reference_project_id":pid,"split":split_map[pid],"split_unit":"PROJECT"} for pid in project_ids]
    for row in rows: row["split"]=split_map[row["reference_project_id"]]
    for row in periods: row["split"]=split_map[row["reference_project_id"]]
    for row in rough_rows: row["split"]=split_map[row["reference_project_id"]]
    for row in param_rows: row["split"]=split_map[row["reference_project_id"]]

    # Inflation index
    inflation=[]
    start=pd.Timestamp("2019-01-01")
    baskets=["STRUCTURAL_STEEL","CONCRETE","ELECTRICAL_EQUIPMENT","MECHANICAL_EQUIPMENT"]
    for region in regions:
        for basket in baskets:
            level=100.0+5*regions.index(region)+2*baskets.index(basket)
            for m in range(96):
                dt=start+pd.DateOffset(months=m)
                shock=0.0
                if 28<=m<=40: shock=0.8+0.15*baskets.index(basket)
                if 60<=m<=67: shock=0.35
                growth=0.18+0.02*baskets.index(basket)+0.01*regions.index(region)+shock+RNG.normal(0,0.18)
                level=max(50.0,level*(1+growth/100))
                inflation.append({"region":region,"basket":basket,"month":dt.date().isoformat(),"index_value":round(level,6),"base_month":"2019-01-01","base_value":100.0})

    # Analog pairs from validation/holdout targets to development pool
    rdf=pd.DataFrame(rows)
    dev=rdf[rdf["split"]=="DEVELOPMENT"].copy()
    targets=rdf[rdf["split"]!="DEVELOPMENT"].head(24).copy()
    numeric=["gross_area_m2","length_km","capacity_units","floors","complexity_index","design_completeness","baseline_cost_usd"]
    means=dev[numeric].mean(); stds=dev[numeric].std().replace(0,1)
    analog=[]
    for _,t in targets.iterrows():
        cand=dev.copy()
        dist=np.sqrt((((cand[numeric].astype(float)-t[numeric].astype(float).to_numpy())/stds.astype(float))**2).sum(axis=1).astype(float))
        dist += (cand["project_type"]!=t["project_type"]).astype(float)*1.5
        dist += (cand["delivery_method"]!=t["delivery_method"]).astype(float)*0.4
        top=cand.assign(distance=dist).nsmallest(5,"distance")
        for rank,(_,r) in enumerate(top.iterrows(),1):
            analog.append({"target_project_id":t["reference_project_id"],"analog_project_id":r["reference_project_id"],"similarity_rank":rank,"distance":round(float(r["distance"]),6),"analog_cost_overrun_pct":r["cost_overrun_pct"],"analog_schedule_overrun_pct":r["schedule_overrun_pct"]})

    # model coefficients (truth used in generator)
    model_truth={
        "response":"baseline_cost_usd",
        "model_family":"SYNTHETIC_PARAMETRIC_COST_GENERATOR",
        "description":"Archetype base plus area, length, capacity, floors, complexity, region and delivery effects with Gaussian noise.",
        "archetype_base_millions":type_base,
        "delivery_effect_fraction":delivery_effect,
        "region_factor":region_factor,
        "coefficients_millions":{"gross_area_m2":0.0009,"length_km":2.6,"capacity_units":0.18,"floors":1.8,"complexity_index":55.0},
        "random_seed":SEED,
    }

    data={
        "reference_projects.csv":pd.DataFrame(rows),
        "reference_project_periods.csv":pd.DataFrame(periods),
        "reference_class_membership.csv":pd.DataFrame(memberships),
        "reference_outcomes.csv":pd.DataFrame(outcomes),
        "anomaly_labels.csv":pd.DataFrame(anomalies),
        "rough_set_decision_table.csv":pd.DataFrame(rough_rows),
        "parametric_cost_training.csv":pd.DataFrame(param_rows),
        "inflation_index.csv":pd.DataFrame(inflation),
        "analogous_pairs.csv":pd.DataFrame(analog),
        "split_manifest.csv":pd.DataFrame(split_rows),
    }
    for name,df in data.items(): write_csv(df,PKG_B1/name,"B1-0.1")
    write_json(model_truth,PKG_B1/"ground_truth_model.json")
    return data


def softmax(x: np.ndarray) -> np.ndarray:
    z=x-np.max(x); e=np.exp(z); return e/e.sum()


def generate_package_b2() -> Dict[str,pd.DataFrame]:
    experts=[]; scenarios=[]; zrows=[]; plts=[]; fuzzy=[]; ds=[]; poss=[]
    n_exp=15; n_scen=24
    terms=np.array([0.10,0.35,0.60,0.85])
    term_names=["GREEN","YELLOW","AMBER","RED"]
    for e in range(n_exp):
        experts.append({"expert_id":f"EXP-{e+1:02d}","expert_role":["PROJECT_MANAGER","SCHEDULER","COST_ENGINEER","RISK_MANAGER","CONSTRUCTION_MANAGER"][e%5],"experience_years":5+(e%10)*2,"base_reliability":round(0.68+0.02*(e%10),6),"bias":round((e-7)*0.008,6)})
    for s in range(n_scen):
        sev=float(np.clip(0.08+0.84*(s/(n_scen-1))+RNG.normal(0,0.035),0.02,0.98))
        completeness=float(np.clip(0.58+0.4*RNG.beta(3,1.5),0.55,1))
        scenarios.append({"scenario_id":f"ESC-{s+1:02d}","scenario_name":f"Epistemic Scenario {s+1}","ground_truth_severity":round(sev,6),"evidence_completeness":round(completeness,6),"ground_truth_status":"GREEN" if sev<0.25 else ("YELLOW" if sev<0.5 else ("AMBER" if sev<0.75 else "RED"))})
    for ex in experts:
        for sc in scenarios:
            rel=float(np.clip(ex["base_reliability"]*sc["evidence_completeness"],0.35,0.98))
            obs=float(np.clip(sc["ground_truth_severity"]+ex["bias"]+RNG.normal(0,(1-rel)*0.22),0,1))
            spread=0.10+(1-rel)*0.18
            zrows.append({"expert_id":ex["expert_id"],"scenario_id":sc["scenario_id"],"assessment_low":round(max(0,obs-spread),6),"assessment_mode":round(obs,6),"assessment_high":round(min(1,obs+spread),6),"reliability":round(rel,6),"reliability_source":"EXPERT_BASE_X_EVIDENCE_COMPLETENESS"})
            logits=-((terms-obs)**2)/(2*(0.12+(1-rel)*0.08)**2)
            probs=softmax(logits)
            plts.append({"expert_id":ex["expert_id"],"scenario_id":sc["scenario_id"],**{f"p_{term_names[i].lower()}":round(float(probs[i]),6) for i in range(4)},"probability_sum":round(float(probs.sum()),6)})
            positive=max(0.0,1-obs); negative=obs; neutral=(1-rel)*0.45
            scale=max(1.0,positive+negative+neutral)
            positive/=scale; negative/=scale; neutral/=scale
            fuzzy.append({
                "expert_id":ex["expert_id"],"scenario_id":sc["scenario_id"],"severity_score":round(obs,6),
                "picture_positive":round(positive,6),"picture_neutral":round(neutral,6),"picture_negative":round(negative,6),
                "hesitant_memberships_json":json.dumps(sorted([round(float(np.clip(obs+d,0,1)),6) for d in (-spread/2,0,spread/2)])),
                "type2_lower_membership":round(max(0,obs-spread),6),"type2_upper_membership":round(min(1,obs+spread),6),
                "pythagorean_membership":round(min(1,obs),6),"pythagorean_nonmembership":round(min(math.sqrt(max(0,1-obs**2)),1),6),
            })
            # DS masses over G/A/R + theta
            g=max(0,1-obs*1.5); r=max(0,(obs-0.4)*1.5); a=max(0,1-g-r); theta=max(0.02,1-rel)
            total=g+a+r+theta
            ds.append({"source_id":ex["expert_id"],"scenario_id":sc["scenario_id"],"mass_green":round(g/total,6),"mass_amber":round(a/total,6),"mass_red":round(r/total,6),"mass_theta":round(theta/total,6),"mass_sum":1.0})
            possibility=np.exp(-((terms-obs)**2)/(2*(0.16+0.06*(1-rel))**2)); possibility=possibility/possibility.max()
            poss.append({"expert_id":ex["expert_id"],"scenario_id":sc["scenario_id"],**{f"poss_{term_names[i].lower()}":round(float(possibility[i]),6) for i in range(4)},"max_possibility":1.0})

    # Belief rule base over cost/schedule/document statuses
    brules=[]
    statuses=["GREEN","AMBER","RED"]
    sevmap={"GREEN":0.1,"AMBER":0.55,"RED":0.9}
    rid=1
    for c in statuses:
        for s in statuses:
            for d in statuses:
                sev=max(sevmap[c],sevmap[s],sevmap[d])*0.65+(sevmap[c]+sevmap[s]+sevmap[d])/3*0.35
                centers=np.array([0.1,0.55,0.9]); probs=softmax(-((centers-sev)**2)/(2*0.18**2))
                brules.append({"rule_id":f"BR-{rid:03d}","cost_state":c,"schedule_state":s,"document_state":d,"rule_weight":1.0,"belief_green":round(float(probs[0]),6),"belief_amber":round(float(probs[1]),6),"belief_red":round(float(probs[2]),6),"belief_sum":round(float(probs.sum()),6)}); rid+=1

    data={
        "expert_profiles.csv":pd.DataFrame(experts),
        "epistemic_scenarios.csv":pd.DataFrame(scenarios),
        "z_number_assessments.csv":pd.DataFrame(zrows),
        "plts_assessments.csv":pd.DataFrame(plts),
        "fuzzy_memberships.csv":pd.DataFrame(fuzzy),
        "ds_mass_assignments.csv":pd.DataFrame(ds),
        "possibility_distributions.csv":pd.DataFrame(poss),
    }
    for name,df in data.items(): write_csv(df,PKG_B2/name,"B2-0.1")
    write_json({"rules":brules,"rule_base_id":"SYNTHETIC_BRB_001","consequent_states":["GREEN","AMBER","RED"],"data_origin":DATA_ORIGIN,"programme_version":PROGRAMME_VERSION},PKG_B2/"belief_rules.json")
    write_json({"ground_truth_scenarios":scenarios,"notes":["Reliability is generated independently from severity.","These fixtures verify implementation behavior and do not establish empirical calibration."]},PKG_B2/"epistemic_ground_truth.json")
    return data


def normalize_decision_matrix(matrix: np.ndarray, directions: List[str]) -> np.ndarray:
    out=np.zeros_like(matrix,dtype=float)
    for j,d in enumerate(directions):
        col=matrix[:,j]
        lo,hi=float(col.min()),float(col.max())
        if abs(hi-lo)<1e-12: out[:,j]=1.0
        elif d=="MIN": out[:,j]=(hi-col)/(hi-lo)
        else: out[:,j]=(col-lo)/(hi-lo)
    return out


def critic_weights(matrix: np.ndarray, directions: List[str]) -> np.ndarray:
    normed=normalize_decision_matrix(matrix,directions)
    std=normed.std(axis=0,ddof=1)
    corr=np.corrcoef(normed,rowvar=False)
    corr=np.nan_to_num(corr,nan=0.0)
    info=std*np.sum(1-corr,axis=1)
    if info.sum()<=1e-12: return np.ones(matrix.shape[1])/matrix.shape[1]
    return info/info.sum()


def topsis_scores(matrix: np.ndarray, weights: np.ndarray, directions: List[str]) -> np.ndarray:
    denom=np.sqrt((matrix**2).sum(axis=0)); denom=np.where(denom==0,1,denom)
    v=(matrix/denom)*weights
    ideal=np.zeros(matrix.shape[1]); anti=np.zeros(matrix.shape[1])
    for j,d in enumerate(directions):
        if d=="MIN": ideal[j]=v[:,j].min(); anti[j]=v[:,j].max()
        else: ideal[j]=v[:,j].max(); anti[j]=v[:,j].min()
    dp=np.sqrt(((v-ideal)**2).sum(axis=1)); dm=np.sqrt(((v-anti)**2).sum(axis=1))
    return dm/(dp+dm+1e-12)


def marcos_scores(matrix: np.ndarray, weights: np.ndarray, directions: List[str]) -> np.ndarray:
    # Standard MARCOS-style utility construction for synthetic benchmark use.
    ideal=[]; anti=[]
    for j,d in enumerate(directions):
        ideal.append(matrix[:,j].min() if d=="MIN" else matrix[:,j].max())
        anti.append(matrix[:,j].max() if d=="MIN" else matrix[:,j].min())
    ideal=np.array(ideal,dtype=float); anti=np.array(anti,dtype=float)
    ext=np.vstack([anti,matrix,ideal])
    n=np.zeros_like(ext,dtype=float)
    for j,d in enumerate(directions):
        if d=="MIN": n[:,j]=ideal[j]/np.maximum(ext[:,j],1e-12)
        else: n[:,j]=ext[:,j]/max(ideal[j],1e-12)
    s=(n*weights).sum(axis=1)
    s_anti=s[0]; s_ideal=s[-1]; s_alt=s[1:-1]
    k_minus=s_alt/max(s_anti,1e-12); k_plus=s_alt/max(s_ideal,1e-12)
    f_plus=k_minus/(k_plus+k_minus+1e-12); f_minus=k_plus/(k_plus+k_minus+1e-12)
    util=(k_plus+k_minus)/(1+(1-f_plus)/(f_plus+1e-12)+(1-f_minus)/(f_minus+1e-12))
    return util


def pareto_front(matrix: np.ndarray, directions: List[str]) -> np.ndarray:
    # Return boolean nondominated mask.
    transformed=matrix.copy().astype(float)
    for j,d in enumerate(directions):
        if d=="MAX": transformed[:,j]=-transformed[:,j]
    n=len(matrix); mask=np.ones(n,dtype=bool)
    for i in range(n):
        for k in range(n):
            if i==k: continue
            if np.all(transformed[k]<=transformed[i]+1e-12) and np.any(transformed[k]<transformed[i]-1e-12):
                mask[i]=False; break
    return mask


def generate_package_b3() -> Dict[str,pd.DataFrame]:
    problems=[]; actions=[]; scenarios=[]; criteria=[]; outcomes=[]; matrix_rows=[]; constraints=[]; payoffs=[]; sensitivity=[]; gt=[]
    action_defs=[
        ("MAINTAIN_PLAN",0.0,0.0,0.0,0.0,0.0),
        ("ADD_CREW",1.6,-10,0.05,0.08,-0.08),
        ("OVERTIME",1.1,-7,0.10,0.15,-0.04),
        ("EXPEDITE_PROCUREMENT",1.4,-9,0.02,0.03,-0.10),
        ("RESEQUENCE_WORK",0.6,-6,0.08,0.05,-0.06),
        ("DEFER_NONCRITICAL_SCOPE",-0.4,-3,0.12,0.02,-0.03),
    ]
    scenario_defs=[
        ("NOMINAL",0.35,0,0.00,0.00,0.00),
        ("PRODUCTIVITY_DROP",0.20,14,0.06,0.04,0.12),
        ("SUPPLY_DISRUPTION",0.20,18,0.03,0.02,0.18),
        ("WEATHER_DELAY",0.15,12,0.02,0.05,0.10),
        ("COMBINED_STRESS",0.10,28,0.09,0.08,0.25),
    ]
    criteria_defs=[
        ("EXPECTED_COST_DELTA_USD","MIN",0.28),
        ("EXPECTED_DELAY_DAYS","MIN",0.26),
        ("QUALITY_RISK","MIN",0.16),
        ("SAFETY_RISK","MIN",0.14),
        ("RESIDUAL_RISK","MIN",0.16),
    ]
    for d in range(1,13):
        did=f"DP-{d:02d}"
        project_id=PROJECT_TEMPLATES[(d-1)%6][0]
        budget=PROJECT_TEMPLATES[(d-1)%6][4]
        stress=0.75+0.05*d
        problems.append({"decision_problem_id":did,"project_id":project_id,"reporting_period":f"P{((d-1)%6)+1:02d}","decision_horizon_days":60,"authority_required":"PROJECT_DIRECTOR" if d%3 else "PROGRAM_EXECUTIVE","budget_cap_usd":round(budget*0.025,2),"crew_capacity_increment":3,"max_overtime_fraction":0.20})
        for aidx,(aname,cost_m,days,qr,sr,rr) in enumerate(action_defs):
            aid=f"{did}-A{aidx}"
            actions.append({"decision_problem_id":did,"action_id":aid,"action_name":aname,"base_direct_cost_usd":round(cost_m*1_000_000*stress,2),"base_delay_effect_days":days,"quality_risk_effect":qr,"safety_risk_effect":sr,"residual_risk_effect":rr,"crew_increment":2 if aname=="ADD_CREW" else 0,"overtime_fraction":0.15 if aname=="OVERTIME" else 0.0,"requires_executive_authority":aname in {"DEFER_NONCRITICAL_SCOPE"}})
        for sidx,(sname,prob,delay,qr,sr,rr) in enumerate(scenario_defs):
            sid=f"{did}-S{sidx}"
            scenarios.append({"decision_problem_id":did,"scenario_id":sid,"scenario_name":sname,"scenario_probability":prob,"delay_shock_days":delay*stress,"quality_shock":qr*stress,"safety_shock":sr*stress,"risk_shock":rr*stress})
        for cname,direction,w in criteria_defs:
            criteria.append({"decision_problem_id":did,"criterion_id":f"{did}-{cname}","criterion_name":cname,"direction":direction,"owner_weight":w,"unit":"USD" if "COST" in cname else ("DAY" if "DELAY" in cname else "0_TO_1")})
        # outcome rows
        for aidx,(aname,cost_m,days,qr_eff,sr_eff,rr_eff) in enumerate(action_defs):
            aid=f"{did}-A{aidx}"
            for sidx,(sname,prob,delay_shock,qr_shock,sr_shock,rr_shock) in enumerate(scenario_defs):
                sid=f"{did}-S{sidx}"
                synergy=0.0
                if aname=="EXPEDITE_PROCUREMENT" and sname=="SUPPLY_DISRUPTION": synergy=-10*stress
                if aname=="ADD_CREW" and sname=="PRODUCTIVITY_DROP": synergy=-6*stress
                if aname=="RESEQUENCE_WORK" and sname=="WEATHER_DELAY": synergy=-5*stress
                cost=(cost_m*1_000_000*stress)+(0.10*budget*(delay_shock/1000))*0.02
                delay=max(-15.0,delay_shock*stress+days+synergy+RNG.normal(0,1.0))
                q=float(np.clip(0.18+qr_shock*stress+qr_eff+0.002*max(0,-days),0,1))
                sa=float(np.clip(0.12+sr_shock*stress+sr_eff+0.003*max(0,-days),0,1))
                rr=float(np.clip(0.20+rr_shock*stress+rr_eff,0,1))
                feasible=not (aname=="OVERTIME" and sa>0.45) and not (aname=="ADD_CREW" and d%4==0)
                outcomes.append({"decision_problem_id":did,"action_id":aid,"scenario_id":sid,"cost_delta_usd":round(cost,2),"delay_days":round(delay,6),"quality_risk":round(q,6),"safety_risk":round(sa,6),"residual_risk":round(rr,6),"feasible":feasible})
        # constraints
        constraints.extend([
            {"decision_problem_id":did,"constraint_id":f"{did}-C1","constraint_type":"BUDGET","expression":"total_action_cost <= budget_cap_usd","right_hand_side":round(budget*0.025,2)},
            {"decision_problem_id":did,"constraint_id":f"{did}-C2","constraint_type":"CREW","expression":"crew_increment <= crew_capacity_increment","right_hand_side":3},
            {"decision_problem_id":did,"constraint_id":f"{did}-C3","constraint_type":"OVERTIME","expression":"overtime_fraction <= max_overtime_fraction","right_hand_side":0.20},
        ])
        # aggregate expected matrix
        odf=pd.DataFrame([r for r in outcomes if r["decision_problem_id"]==did])
        sdf=pd.DataFrame([r for r in scenarios if r["decision_problem_id"]==did])
        probs={r["scenario_id"]:r["scenario_probability"] for r in sdf.to_dict("records")}
        aids=[f"{did}-A{i}" for i in range(len(action_defs))]
        matrix=[]
        for aid in aids:
            sub=odf[odf["action_id"]==aid]
            vals=[]
            for col in ["cost_delta_usd","delay_days","quality_risk","safety_risk","residual_risk"]:
                vals.append(float(sum(row[col]*probs[row["scenario_id"]] for row in sub.to_dict("records"))))
            matrix.append(vals)
            matrix_rows.append({"decision_problem_id":did,"action_id":aid,"expected_cost_delta_usd":round(vals[0],2),"expected_delay_days":round(vals[1],6),"quality_risk":round(vals[2],6),"safety_risk":round(vals[3],6),"residual_risk":round(vals[4],6)})
        matrix=np.array(matrix,float); dirs=[x[1] for x in criteria_defs]; owner_w=np.array([x[2] for x in criteria_defs],float)
        cw=critic_weights(matrix,dirs); ts=topsis_scores(matrix,cw,dirs); ms=marcos_scores(matrix,owner_w,dirs); pf=pareto_front(matrix[:,[0,1,4]],["MIN","MIN","MIN"])
        # payoff/loss per action-scenario; scale dimensions
        loss=np.zeros((len(aids),len(scenario_defs)))
        for ai,aid in enumerate(aids):
            sub=odf[odf["action_id"]==aid].sort_values("scenario_id")
            loss[ai,:]=sub["cost_delta_usd"].to_numpy()/1_000_000 + np.maximum(0,sub["delay_days"].to_numpy())*0.18 + sub["residual_risk"].to_numpy()*8 + sub["quality_risk"].to_numpy()*4 + sub["safety_risk"].to_numpy()*5
        best_per_s=loss.min(axis=0); regret=loss-best_per_s; max_regret=regret.max(axis=1)
        for ai,aid in enumerate(aids):
            for si in range(len(scenario_defs)):
                payoffs.append({"decision_problem_id":did,"action_id":aid,"scenario_id":f"{did}-S{si}","loss_value":round(float(loss[ai,si]),6),"regret_value":round(float(regret[ai,si]),6)})
        # LP: continuous intensities for crew, overtime, expedite, resequence
        c=np.array([1.6,1.1,1.4,0.6])*1_000_000*stress + np.array([-10,-7,-9,-6])*180_000*stress
        Aub=np.array([[1.6,1.1,1.4,0.6],[2,0,0,0],[0,0.15,0,0]])
        bub=np.array([budget*0.025/1_000_000,3,0.20])
        res=linprog(c,A_ub=Aub,b_ub=bub,bounds=[(0,1)]*4,method="highs")
        lp_solution=res.x if res.success else np.full(4,np.nan)
        # sensitivity: perturb each weight
        base_top=aids[int(np.argmax(topsis_scores(matrix,owner_w,dirs)))]
        changed=0; total_cases=0
        for j,(cname,_,w) in enumerate(criteria_defs):
            for factor in [0.8,1.2]:
                wp=owner_w.copy(); wp[j]*=factor; wp/=wp.sum(); scores=topsis_scores(matrix,wp,dirs); top=aids[int(np.argmax(scores))]
                changed+=int(top!=base_top); total_cases+=1
                sensitivity.append({"decision_problem_id":did,"criterion_name":cname,"weight_factor":factor,"selected_action_id":top,"base_selected_action_id":base_top,"selection_changed":top!=base_top})
        gt.append({
            "decision_problem_id":did,"critic_weights_json":json.dumps({criteria_defs[j][0]:round(float(cw[j]),6) for j in range(len(cw))},sort_keys=True),
            "critic_topsis_top_action_id":aids[int(np.argmax(ts))],"marcos_top_action_id":aids[int(np.argmax(ms))],
            "minimax_regret_action_id":aids[int(np.argmin(max_regret))],"minimax_regret_value":round(float(np.min(max_regret)),6),
            "pareto_action_ids":"|".join([aids[i] for i,v in enumerate(pf) if v]),
            "lp_success":bool(res.success),"lp_objective_value":round(float(res.fun),6) if res.success else np.nan,
            "lp_solution_json":json.dumps({"add_crew":round(float(lp_solution[0]),6),"overtime":round(float(lp_solution[1]),6),"expedite":round(float(lp_solution[2]),6),"resequence":round(float(lp_solution[3]),6)},sort_keys=True),
            "decision_sensitivity_change_rate":round(changed/total_cases,6),
        })
    lp_models=[]
    for p in problems:
        did=p["decision_problem_id"]
        lp_models.append({
            "decision_problem_id":did,
            "variables":["add_crew_intensity","overtime_intensity","expedite_intensity","resequence_intensity"],
            "bounds":{"lower":[0,0,0,0],"upper":[1,1,1,1]},
            "objective_description":"Minimize action cost plus monetized schedule delay in the synthetic benchmark.",
            "constraints":["action_cost <= budget_cap","crew_increment <= capacity","overtime <= limit"],
            "ground_truth_row":did,
        })
    data={
        "decision_problems.csv":pd.DataFrame(problems),"actions.csv":pd.DataFrame(actions),"scenarios.csv":pd.DataFrame(scenarios),
        "criteria.csv":pd.DataFrame(criteria),"action_scenario_outcomes.csv":pd.DataFrame(outcomes),
        "alternative_criteria_matrix.csv":pd.DataFrame(matrix_rows),"constraints.csv":pd.DataFrame(constraints),
        "payoff_matrices.csv":pd.DataFrame(payoffs),"sensitivity_cases.csv":pd.DataFrame(sensitivity),
        "ground_truth_decisions.csv":pd.DataFrame(gt),
    }
    for name,df in data.items(): write_csv(df,PKG_B3/name,"B3-0.1")
    write_json({"models":lp_models,"data_origin":DATA_ORIGIN,"programme_version":PROGRAMME_VERSION},PKG_B3/"lp_models.json")
    return data


def generate_package_c(b1: Dict[str,pd.DataFrame], b3: Dict[str,pd.DataFrame]) -> Dict[str,pd.DataFrame]:
    candidates=[
        ("3.8","Parametric Cost Index",3,"PROTOTYPE_AFTER_B1","B1_reference_population","Compare calibrated parametric regression with naive archetype mean."),
        ("7.7","Plithogenic Sets",7,"REMAIN_DISABLED_PENDING_INCREMENTAL_VALUE","B2_expert_epistemic","Requires contradiction/appurtenance structure and comparison with simpler fuzzy methods."),
        ("7.9","Quantum Probability",7,"REMAIN_DISABLED_PENDING_ORDER_EFFECT_EVIDENCE","C_quantum","Requires order/context effects and classical-model comparison."),
        ("7.20","Hypersoft Sets",7,"REMAIN_DISABLED_PENDING_INCREMENTAL_VALUE","C_hypersoft","Requires multiargument parameter domains and simpler-method comparison."),
        ("10.1","Multi-Objective Optimization",10,"PROTOTYPE_AFTER_B3","B3_decision_optimization","Use explicit alternatives/objectives/constraints and retain human preference selection."),
        ("10.2","Linear Programming",10,"PROTOTYPE_AFTER_B3","B3_decision_optimization","Use explicit LP formulation and solver agreement."),
        ("10.5","Decision Sensitivity Matrix",10,"PROTOTYPE_AFTER_B3","B3_decision_optimization","Perturb weights/assumptions and measure selected-action stability."),
        ("10.6","Pareto Frontier Analysis",10,"PROTOTYPE_AFTER_B3","B3_decision_optimization","Interpret nondominated alternatives from the multiobjective decision set."),
    ]
    cand_df=pd.DataFrame([{"module_id":m,"module_name":n,"category_number":c,"activation_recommendation":r,"required_source_package":p,"activation_basis":b} for m,n,c,r,p,b in candidates])
    # Parametric benchmark: simple OLS on synthetic development, compare holdout against archetype mean.
    df=b1["parametric_cost_training.csv"].copy()
    cat_cols=["project_type","delivery_method","region"]
    X=pd.get_dummies(df[["gross_area_m2","length_km","capacity_units","floors","complexity_index","design_completeness","location_factor"]+cat_cols],columns=cat_cols,drop_first=False,dtype=float)
    y=df["baseline_cost_usd"].to_numpy(float)
    train=df["split"]=="DEVELOPMENT"; hold=df["split"]=="LOCKED_HOLDOUT"
    Xtrain=np.c_[np.ones(train.sum()),X.loc[train].to_numpy(float)]; Xhold=np.c_[np.ones(hold.sum()),X.loc[hold].to_numpy(float)]
    beta=np.linalg.lstsq(Xtrain,y[train],rcond=None)[0]; pred=Xhold@beta
    naive=df.loc[hold].groupby("project_type")["baseline_cost_usd"].transform("mean").to_numpy()
    mae=float(np.mean(np.abs(pred-y[hold]))); naive_mae=float(np.mean(np.abs(naive-y[hold])))
    bench=pd.DataFrame([{"module_id":"3.8","model":"SYNTHETIC_OLS_PARAMETRIC_COST","holdout_projects":int(hold.sum()),"holdout_mae_usd":round(mae,2),"naive_archetype_mean_mae_usd":round(naive_mae,2),"improvement_fraction":round(1-mae/naive_mae,6),"activation_gate_passed":mae<naive_mae}])
    # Plithogenic fixtures
    attrs=["COST","SCHEDULE","QUALITY","RISK"]
    alternatives=["SUPPLIER_A","SUPPLIER_B","SUPPLIER_C","SUPPLIER_D"]
    attr_rows=[]; app=[]; contradictions=[]
    ideal={"COST":"LOW","SCHEDULE":"FAST","QUALITY":"HIGH","RISK":"LOW"}
    values={"COST":["LOW","MEDIUM","HIGH"],"SCHEDULE":["FAST","NORMAL","SLOW"],"QUALITY":["HIGH","MEDIUM","LOW"],"RISK":["LOW","MEDIUM","HIGH"]}
    for a in attrs:
        for v in values[a]: attr_rows.append({"attribute":a,"attribute_value":v,"dominant_value":ideal[a],"value_rank":values[a].index(v)+1})
        for v1 in values[a]:
            for v2 in values[a]: contradictions.append({"attribute":a,"value_a":v1,"value_b":v2,"contradiction_degree":round(abs(values[a].index(v1)-values[a].index(v2))/(len(values[a])-1),6)})
    for alt_i,alt in enumerate(alternatives):
        for a in attrs:
            for v in values[a]:
                center=(alt_i+values[a].index(v))%3
                degree=float(np.clip(0.15+0.35*(2-center)+RNG.normal(0,0.04),0,1))
                app.append({"alternative_id":alt,"attribute":a,"attribute_value":v,"appurtenance_degree":round(degree,6)})
    # Hypersoft fixtures
    universe=pd.DataFrame([{"alternative_id":a,"alternative_name":a.replace("_"," ").title()} for a in ["PLAN_A","PLAN_B","PLAN_C","PLAN_D"]])
    param_groups={"COST_LEVEL":["LOW","MEDIUM","HIGH"],"DELIVERY_SPEED":["FAST","NORMAL","SLOW"],"QUALITY_LEVEL":["HIGH","MEDIUM"],"CARBON_LEVEL":["LOW","HIGH"]}
    params=[]
    for g,vals in param_groups.items():
        for v in vals: params.append({"parameter_group":g,"parameter_value":v})
    approx=[]
    combo_id=1
    for cost in param_groups["COST_LEVEL"]:
        for speed in param_groups["DELIVERY_SPEED"]:
            for qual in param_groups["QUALITY_LEVEL"]:
                for carbon in param_groups["CARBON_LEVEL"]:
                    combo=f"HSC-{combo_id:03d}"; combo_id+=1
                    for ai,alt in enumerate(universe["alternative_id"]):
                        score=0.5+0.12*(2-["LOW","MEDIUM","HIGH"].index(cost))-0.10*["FAST","NORMAL","SLOW"].index(speed)+0.12*(1-["HIGH","MEDIUM"].index(qual))+0.08*(1-["LOW","HIGH"].index(carbon))+0.03*ai
                        approx.append({"combination_id":combo,"cost_level":cost,"delivery_speed":speed,"quality_level":qual,"carbon_level":carbon,"alternative_id":alt,"membership_degree":round(float(np.clip(score,0,1)),6)})
    # Quantum order-effect synthetic responses
    qrows=[]; n=1200
    for i in range(n):
        order="A_THEN_B" if i%2==0 else "B_THEN_A"
        if order=="A_THEN_B":
            a=RNG.random()<0.62
            pb=0.70 if a else 0.36
            b=RNG.random()<pb
        else:
            b=RNG.random()<0.57
            pa=0.54 if b else 0.42
            a=RNG.random()<pa
        qrows.append({"synthetic_respondent_id":f"Q-{i+1:04d}","question_order":order,"response_a_yes":bool(a),"response_b_yes":bool(b)})
    quantum_params={"model_id":"SYNTHETIC_ORDER_EFFECT_001","p_a_yes_when_first":0.62,"p_b_yes_given_a_yes":0.70,"p_b_yes_given_a_no":0.36,"p_b_yes_when_first":0.57,"p_a_yes_given_b_yes":0.54,"p_a_yes_given_b_no":0.42,"intended_use":"Implementation and classical-versus-contextual model comparison only","data_origin":DATA_ORIGIN}
    # Activation plan
    plan=[]
    for row in cand_df.to_dict("records"):
        baseline={"3.8":"Archetype mean","7.7":"Picture fuzzy / DST","7.9":"Classical conditional probability","7.20":"Simpler MCDM/fuzzy representation","10.1":"Explicit alternative comparison","10.2":"Hand-solved LP","10.5":"Base decision model","10.6":"Dominance enumeration"}[row["module_id"]]
        plan.append({"module_id":row["module_id"],"module_name":row["module_name"],"baseline_comparator":baseline,"required_metrics":"correctness|incremental_value|interpretability|runtime|sensitivity","activation_rule":"Owner approval after canonical structure, tests, and incremental-value evidence","default_state":"DISABLED" if row["module_id"] in {"7.7","7.9","7.20"} else "PROTOTYPE_ONLY"})
    reuse=[]
    for mid,name,cat,rec,source,basis in candidates:
        reuse.append({"module_id":mid,"module_name":name,"reused_package":source,"additional_c_fixture_required":mid in {"7.7","7.9","7.20"}})
    data={
        "activation_candidates.csv":cand_df,
        "activation_benchmark_plan.csv":pd.DataFrame(plan),
        "parametric_cost_benchmark.csv":bench,
        "plithogenic_attributes.csv":pd.DataFrame(attr_rows),
        "plithogenic_appurtenance.csv":pd.DataFrame(app),
        "plithogenic_contradictions.csv":pd.DataFrame(contradictions),
        "hypersoft_universe.csv":universe,
        "hypersoft_parameters.csv":pd.DataFrame(params),
        "hypersoft_approximation.csv":pd.DataFrame(approx),
        "quantum_order_effects.csv":pd.DataFrame(qrows),
        "reuse_manifest.csv":pd.DataFrame(reuse),
    }
    for name,df in data.items(): write_csv(df,PKG_C/name,"C-0.1")
    write_json(quantum_params,PKG_C/"quantum_model_parameters.json")
    return data


def create_readmes() -> None:
    root_readme=f"""# Opus Gubernatio Synthetic Evidence and Decision Programme v0.1

This release contains three generated packages:

- **Package A:** synthetic canonical project structures for schedule, cost-risk, system, weather, claims and specification modules.
- **Package B:** synthetic reference populations, labelled training cases, expert/epistemic structures and decision/optimization objects.
- **Package C:** optional-module activation fixtures and benchmark plans, reusing Packages A and B.

All records are labelled `{DATA_ORIGIN}` and `not_for_empirical_validation = true`.

## Permitted use

- implementation fidelity;
- known-answer testing;
- structural verification;
- solver agreement;
- edge and abstention behavior;
- controlled sensitivity analysis;
- document-to-module adapter development.

## Not established by this package

- real-world predictive accuracy;
- empirical calibration;
- universal thresholds;
- field validation;
- causal benefit to practitioners.

## Reproducibility

- Programme version: `{PROGRAMME_VERSION}`
- Random seed: `{SEED}`
- Generator: `{GENERATOR_VERSION}`
- File checksums: `CHECKSUMS.sha256`
- Validation report: `VALIDATION_SUMMARY.md`
"""
    (ROOT/"README.md").write_text(root_readme,encoding="utf-8")
    (PKG_A/"README.md").write_text("""# Package A — Synthetic Canonical Project-Structure Corpus

Six integrated synthetic projects across six reporting periods. The package supplies activity networks, stochastic durations, LOB production flow, CCPM buffers, DSM dependencies, system-dynamics states, queue events, agent histories, discrete-event logs, weather/activity links, claims/dispute stages, specification conflicts and project cost-risk structures.

The data are synthetic implementation fixtures, not historical project evidence.
""",encoding="utf-8")
    (PKG_B/"README.md").write_text("""# Package B — Synthetic Reference, Training, Expert and Decision Data

- B1 contains a 360-project synthetic completed-project population, period histories, reference classes, anomaly labels, rough-set table, parametric-cost data and inflation indices.
- B2 contains expert-style epistemic structures, belief rules, Z-number assessments, PLTS, fuzzy memberships, Dempster-Shafer masses and possibility distributions.
- B3 contains explicit actions, scenarios, criteria, constraints, payoff matrices, LP specifications, Pareto sets, minimax-regret and ranking ground truth.
""",encoding="utf-8")
    (PKG_C/"README.md").write_text("""# Package C — Optional-Module Activation Laboratory

This package does not authorize activation. It provides the fixtures and benchmark plan required to evaluate the eight disabled/optional modules. Multi-objective, LP, sensitivity and Pareto methods reuse B3; parametric cost reuses B1; Plithogenic, Hypersoft and Quantum Probability receive small method-specific synthetic fixtures.
""",encoding="utf-8")


def create_module_asset_map() -> pd.DataFrame:
    rows=[]
    for mid,name,cat,pkg,files in MODULE_MAP:
        rows.append({"module_id":mid,"module_name":name,"category_number":cat,"category_name":CATEGORY_NAMES[cat],"synthetic_package":pkg,"primary_files":"|".join(files),"proposed_owner_action":"IMPLEMENT_OR_TEST_WITH_SYNTHETIC_FIXTURES","data_origin":DATA_ORIGIN})
    df=pd.DataFrame(rows)
    write_csv(df,ROOT/"module_asset_map.csv","ROOT-0.1")
    return df


def create_schema_catalog() -> pd.DataFrame:
    rows=[]
    for path in sorted(ROOT.rglob("*.csv")):
        if path.name in {"MANIFEST.csv","data_dictionary.csv"}: continue
        try: df=pd.read_csv(path,nrows=50)
        except Exception: continue
        rel=str(path.relative_to(ROOT))
        for col in df.columns:
            if col in {"record_hash"}: role="integrity"
            elif col in {"data_origin","programme_version","package_version","generator_version","random_seed","not_for_empirical_validation"}: role="provenance"
            elif col.endswith("_id") or col in {"project_id","period_id","reference_project_id"}: role="identifier"
            elif any(k in col for k in ["ground_truth","expected","p50","p80","probability","score","ratio","value","cost","duration","days","risk","cpi","spi","float"]): role="analytical"
            else: role="attribute"
            rows.append({"file":rel,"field":col,"pandas_dtype":str(df[col].dtype),"role":role,"description":"Synthetic programme field; see package README and module map.","unit":"USD" if "usd" in col.lower() else ("day" if "day" in col.lower() else ("0_to_1" if any(x in col.lower() for x in ["fraction","probability","risk","reliability","membership","ratio"]) else "as_named"))})
    ddf=pd.DataFrame(rows)
    ddf.to_csv(ROOT/"data_dictionary.csv",index=False)
    write_json({"programme_version":PROGRAMME_VERSION,"files":{f:grp[["field","pandas_dtype","role","unit"]].to_dict("records") for f,grp in ddf.groupby("file")}},SCHEMAS/"schema_catalog.json")
    return ddf


def validate_programme() -> Dict[str, Any]:
    checks=[]
    def ck(name: str, ok: bool, detail: str=""):
        checks.append({"check":name,"passed":bool(ok),"detail":detail})
    # File and data checks
    for p in ROOT.rglob("*.csv"):
        if p.name in {"MANIFEST.csv"}: continue
        try:
            df=pd.read_csv(p)
            ck(f"load:{p.relative_to(ROOT)}",True,f"rows={len(df)} cols={len(df.columns)}")
            if len(df)>0 and "record_hash" in df.columns:
                ck(f"record_hash_present:{p.relative_to(ROOT)}",df["record_hash"].notna().all())
            if "probability_sum" in df.columns:
                ck(f"probability_sum:{p.relative_to(ROOT)}",np.allclose(df["probability_sum"],1,atol=1e-5))
            if "mass_sum" in df.columns:
                ck(f"mass_sum:{p.relative_to(ROOT)}",np.allclose(df["mass_sum"],1,atol=1e-5))
        except Exception as e:
            ck(f"load:{p.relative_to(ROOT)}",False,str(e))
    # Key structural checks
    projects=pd.read_csv(PKG_A/"projects.csv")
    periods=pd.read_csv(PKG_A/"reporting_periods.csv")
    ck("package_A_has_6_projects",len(projects)==6)
    ck("package_A_has_36_periods",len(periods)==36)
    ref=pd.read_csv(PKG_B1/"reference_projects.csv")
    ck("package_B1_has_360_reference_projects",len(ref)==360)
    splits=ref.groupby("split").size().to_dict()
    ck("project_level_splits_present",set(splits)=={"DEVELOPMENT","VALIDATION","LOCKED_HOLDOUT"},str(splits))
    gt=pd.read_csv(PKG_B3/"ground_truth_decisions.csv")
    ck("package_B3_has_12_decision_problems",len(gt)==12)
    # No project overlap in split manifest
    split=pd.read_csv(PKG_B1/"split_manifest.csv")
    ck("unique_reference_split",split["reference_project_id"].is_unique)
    # Schedule p80 >= p50
    sgt=pd.read_csv(PKG_A/"schedule_ground_truth.csv")
    ck("schedule_p80_ge_p50",bool((sgt["p80_finish_day"]>=sgt["p50_finish_day"]).all()))
    cgt=pd.read_csv(PKG_A/"cost_risk_ground_truth.csv")
    ck("cost_p80_ge_p50",bool((cgt["p80_total_cost_usd"]>=cgt["p50_total_cost_usd"]).all()))
    # Package C candidates exactly 8
    cands=pd.read_csv(PKG_C/"activation_candidates.csv")
    ck("package_C_has_8_candidates",len(cands)==8)
    passed=all(c["passed"] for c in checks)
    report={"programme_version":PROGRAMME_VERSION,"generated_at":datetime.utcnow().isoformat()+"Z","checks":checks,"passed":passed,"check_count":len(checks),"failed_count":sum(not c["passed"] for c in checks)}
    write_json(report,ROOT/"validation_report.json")
    lines=["# Validation Summary","",f"- Programme: `{PROGRAMME_VERSION}`",f"- Checks: **{len(checks)}**",f"- Failed: **{report['failed_count']}**",f"- Overall: **{'PASS' if passed else 'FAIL'}**","","| Check | Result | Detail |","|---|---|---|"]
    for c in checks: lines.append(f"| {c['check']} | {'PASS' if c['passed'] else 'FAIL'} | {str(c['detail']).replace('|','/')} |")
    (ROOT/"VALIDATION_SUMMARY.md").write_text("\n".join(lines),encoding="utf-8")
    if not passed:
        raise RuntimeError("Validation failed")
    return report


def create_manifest_and_checksums() -> pd.DataFrame:
    rows=[]; checksum_lines=[]
    for p in sorted(ROOT.rglob("*")):
        if not p.is_file() or p.name in {"CHECKSUMS.sha256","MANIFEST.csv"}: continue
        raw=p.read_bytes(); sha=hashlib.sha256(raw).hexdigest(); rel=str(p.relative_to(ROOT))
        if p.suffix.lower()==".csv":
            try: count=len(pd.read_csv(p))
            except Exception: count=None
        else: count=None
        rows.append({"file":rel,"bytes":len(raw),"sha256":sha,"row_count":count,"data_origin":DATA_ORIGIN})
        checksum_lines.append(f"{sha}  {rel}")
    mdf=pd.DataFrame(rows)
    mdf.to_csv(ROOT/"MANIFEST.csv",index=False)
    (ROOT/"CHECKSUMS.sha256").write_text("\n".join(checksum_lines)+"\n",encoding="utf-8")
    return mdf


def create_overview_workbook(manifest: pd.DataFrame, module_map: pd.DataFrame, validation: Dict[str,Any]) -> None:
    wb=Workbook(); wb.remove(wb.active)
    dark="17365D"; white="FFFFFF"; teal="DDEBF7"; green="E2F0D9"; orange="FCE4D6"; purple="E4DFEC"; gray="E7E6E6"; red="F4CCCC"
    thin=Side(style="thin",color="B7B7B7")
    def style_sheet(ws, widths=None):
        ws.sheet_view.showGridLines=False
        ws.freeze_panes="A2"
        for cell in ws[1]:
            cell.fill=PatternFill("solid",fgColor=dark); cell.font=Font(color=white,bold=True); cell.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
        ws.auto_filter.ref=ws.dimensions
        for row in ws.iter_rows():
            for c in row:
                c.alignment=Alignment(vertical="top",wrap_text=True)
        if widths:
            for i,w in enumerate(widths,1): ws.column_dimensions[get_column_letter(i)].width=w
        else:
            for col in range(1,ws.max_column+1):
                mx=max(len(str(ws.cell(r,col).value or "")) for r in range(1,min(ws.max_row,200)+1)); ws.column_dimensions[get_column_letter(col)].width=min(max(mx+2,12),45)
    ws=wb.create_sheet("Overview")
    overview=[
        ["Programme","Opus Gubernatio Synthetic Evidence and Decision Programme"],
        ["Version",PROGRAMME_VERSION],["Random seed",SEED],["Data origin",DATA_ORIGIN],
        ["Package A","6 integrated projects × 6 periods plus canonical structural fixtures"],
        ["Package B1","360-project reference/training population"],["Package B2","Expert and epistemic structures"],
        ["Package B3","12 decision problems with actions, scenarios, constraints and ground truth"],
        ["Package C","8 optional/disabled activation candidates"],["Validation",f"PASS — {validation['check_count']} checks"],
        ["Warning","Synthetic fixtures verify implementation; they do not establish empirical calibration or field validity."],
    ]
    ws.append(["Item","Value"])
    for r in overview: ws.append(r)
    style_sheet(ws,[24,90])
    for r in range(2,ws.max_row+1):
        ws.cell(r,1).font=Font(bold=True,color="666666")
        ws.cell(r,2).fill=PatternFill("solid",fgColor=orange if ws.cell(r,1).value=="Warning" else teal)
    ws2=wb.create_sheet("Module Asset Map")
    ws2.append(list(module_map.columns))
    for row in module_map.itertuples(index=False): ws2.append(list(row))
    style_sheet(ws2,[12,34,12,42,18,70,28,28])
    for r in range(2,ws2.max_row+1):
        pkg=str(ws2.cell(r,5).value); fill=green if pkg.startswith("A") else (teal if pkg.startswith("B") else purple)
        ws2.cell(r,5).fill=PatternFill("solid",fgColor=fill)
    ws3=wb.create_sheet("File Manifest")
    ws3.append(list(manifest.columns))
    for row in manifest.itertuples(index=False): ws3.append(list(row))
    style_sheet(ws3,[65,14,70,12,30])
    ws4=wb.create_sheet("Package Counts")
    counts=[]
    for file,grp in manifest.groupby(manifest["file"].str.split("/").str[0]):
        counts.append([file,int(grp["row_count"].fillna(0).sum()),len(grp),int(grp["bytes"].sum())])
    ws4.append(["Top-level package","Total CSV rows","Files","Bytes"])
    for r in counts: ws4.append(r)
    style_sheet(ws4,[45,18,12,18])
    ws5=wb.create_sheet("Validation")
    ws5.append(["Check","Result","Detail"])
    for c in validation["checks"]: ws5.append([c["check"],"PASS" if c["passed"] else "FAIL",c["detail"]])
    style_sheet(ws5,[65,12,70])
    for r in range(2,ws5.max_row+1): ws5.cell(r,2).fill=PatternFill("solid",fgColor=green if ws5.cell(r,2).value=="PASS" else red)
    wb.save(ROOT/"package_summary.xlsx")


def copy_scripts() -> None:
    src=Path(__file__)
    shutil.copy2(src,GENERATORS/src.name)
    validator = '''from pathlib import Path\nimport json, pandas as pd, numpy as np\nROOT=Path(__file__).resolve().parents[1]\nreport=json.loads((ROOT/"validation_report.json").read_text())\nif not report.get("passed"):\n    raise SystemExit("Stored validation report is not passing")\nfor p in ROOT.rglob("*.csv"):\n    if p.name=="MANIFEST.csv": continue\n    pd.read_csv(p)\nprint(f"PASS: {report['check_count']} stored checks and all CSV files load")\n'''
    (VALIDATORS/"validate_synthetic_programme.py").write_text(validator,encoding="utf-8")


def zip_programme() -> Path:
    zpath=Path("/mnt/data/Opus_Gubernatio_Synthetic_Programme_v0.1.zip")
    if zpath.exists(): zpath.unlink()
    with zipfile.ZipFile(zpath,"w",zipfile.ZIP_DEFLATED) as z:
        for p in sorted(ROOT.rglob("*")):
            if p.is_file(): z.write(p,p.relative_to(ROOT.parent))
    return zpath


def main():
    prepare_dirs()
    create_readmes()
    a=generate_package_a()
    b1=generate_package_b1()
    b2=generate_package_b2()
    b3=generate_package_b3()
    c=generate_package_c(b1,b3)
    module_map=create_module_asset_map()
    copy_scripts()
    create_schema_catalog()
    validation=validate_programme()
    manifest=create_manifest_and_checksums()
    create_overview_workbook(manifest,module_map,validation)
    # Recreate manifest after workbook added
    manifest=create_manifest_and_checksums()
    zpath=zip_programme()
    print(json.dumps({"root":str(ROOT),"zip":str(zpath),"files":len(manifest),"validation_checks":validation["check_count"]},indent=2))

if __name__=="__main__":
    main()
